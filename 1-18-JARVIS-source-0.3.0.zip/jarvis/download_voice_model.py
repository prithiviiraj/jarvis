"""Build-time only, never imported by runtime. Pinned and checksum-verified."""
from pathlib import Path
import hashlib
from huggingface_hub import snapshot_download
REVISION='ebe41f70d5b6dfa9166e2c581c45c9c0cfc57b66'
HASHES={
'model.bin':'d01c3014881c9c6f3133c182f3d2887eb6ca1c789a7538c5c007196857a0a6a9',
'config.json':'56a6d8110d311f19c8f0471e562832c7527f146b567275bfca59fcf7c184da9a',
 'tokenizer.json':'fb7b63191e9bb045082c79fd742a3106a12c99513ab30df4a0d47fa6cb6fd0ab',
 'vocabulary.txt':'34ce3fe1c5041027b3f8d42912270993f986dbc4bb34cf27f951e34a1e453913'}
if __name__=='__main__':
    dest=Path('models/whisper-base')
    snapshot_download('Systran/faster-whisper-base',revision=REVISION,local_dir=str(dest),allow_patterns=list(HASHES))
    for name,digest in HASHES.items():
        if hashlib.sha256((dest/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('Bundled model checksum mismatch: '+name)
    print('Whisper base pinned assets verified. Runtime needs no internet.')
