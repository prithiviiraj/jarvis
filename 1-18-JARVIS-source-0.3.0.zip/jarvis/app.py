"""JARVIS desktop. All monitoring starts OFF and requires session consent."""
import io
import os
import queue
import threading
import time
import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
from core import Client, LocalError, screenshot, ROOT
from voice import Recorder, Transcriber, WindowsSpeech
from startup import get_startup, set_startup
from monitor import ScreenSchedule, CameraMonitor, SCREEN_PROMPT

ctk.set_appearance_mode('dark')
ctk.set_default_color_theme('dark-blue')
BG='#0d0f14'; PANEL='#151922'; MUTED='#8991a5'; ACCENT='#a6ffcf'

class App:
    def __init__(self,root):
        self.root=root
        self.client=Client()
        self.events=queue.Queue()
        self.schedule=ScreenSchedule()
        self.camera=CameraMonitor(self.events)
        self.camera_on=False
        self.busy=False
        self.closed=False
        self.recording=False
        self.voice_request=False
        self.speaking=False
        self.recorder=Recorder()
        self.transcriber=Transcriber(ROOT/'models'/'whisper-base')
        self.tts=WindowsSpeech(self.events)
        self.voice_map={}
        self.speech_enabled=tk.BooleanVar(value=False)
        self.session_start=time.monotonic()
        self.last_presence=None
        self.next_break=float("inf")
        self.toast=None
        root.title(self.client.config.get('project_name','JARVIS'))
        width=min(1140,root.winfo_screenwidth()-40)
        height=min(760,root.winfo_screenheight()-100)
        root.geometry('%dx%d+20+20'%(width,height)); root.minsize(900,620)
        root.configure(fg_color=BG)
        root.grid_columnconfigure(1,weight=1); root.grid_rowconfigure(0,weight=1)
        self.sidebar=ctk.CTkFrame(root,width=200,fg_color='#11141b',corner_radius=0)
        self.sidebar.grid(row=0,column=0,sticky='nsew'); self.sidebar.grid_propagate(False)
        ctk.CTkLabel(self.sidebar,text='J A R V I S',font=('Segoe UI',26,'bold'),text_color=ACCENT).pack(anchor='w',padx=24,pady=(30,2))
        ctk.CTkLabel(self.sidebar,text='Your local companion',text_color=MUTED).pack(anchor='w',padx=24)
        ctk.CTkLabel(self.sidebar,text='WORKSPACE',text_color=MUTED,font=('Segoe UI',11,'bold')).pack(anchor='w',padx=24,pady=(38,12))
        ctk.CTkButton(self.sidebar,text='Conversation',fg_color='#253d36',text_color=ACCENT,anchor='w',height=42,command=lambda:self.input.focus_set()).pack(fill='x',padx=18)
        for label,action in (('Screen context',lambda:self.ask(True)),('Mentor activity',lambda:self.feed.focus_set()),('Local privacy',self.privacy)):
            ctk.CTkButton(self.sidebar,text=label,command=action,fg_color='transparent',text_color='#b9c0cf',anchor='w',height=40,hover_color='#242a38').pack(fill='x',padx=18)
        ctk.CTkLabel(self.sidebar,text='No cloud fallback\nNo auto-start\nNo saved frames',text_color=MUTED,justify='left').pack(side='bottom',anchor='w',padx=24,pady=26)
        main=ctk.CTkFrame(root,fg_color=BG,corner_radius=0)
        main.grid(row=0,column=1,sticky='nsew',padx=24,pady=20)
        main.grid_columnconfigure(0,weight=1); main.grid_rowconfigure(2,weight=1)
        header=ctk.CTkFrame(main,fg_color='transparent')
        header.grid(row=0,column=0,sticky='ew',pady=(0,18)); header.grid_columnconfigure(0,weight=1)
        ctk.CTkLabel(header,text='A little focus. A useful next step.',font=('Segoe UI',24,'bold')).grid(row=0,column=0,sticky='w')
        ctk.CTkLabel(header,text='Local model, visible controls, your pace.',text_color=MUTED).grid(row=1,column=0,sticky='w')
        self.link=ctk.CTkButton(header,text='Check LM Studio',width=135,fg_color='#242a38',command=self.check_server)
        self.link.grid(row=0,column=1,rowspan=2,padx=(10,0))
        controls=ctk.CTkFrame(main,fg_color=PANEL,corner_radius=14)
        controls.grid(row=1,column=0,sticky='ew',pady=(0,16)); controls.grid_columnconfigure(3,weight=1)
        self.screen_var=tk.BooleanVar(value=False); self.camera_var=tk.BooleanVar(value=False)
        self.screen_toggle=ctk.CTkSwitch(controls,text='Screen agent',variable=self.screen_var,command=self.toggle_screen,progress_color='#3a8c68')
        self.screen_toggle.grid(row=0,column=0,sticky='w',padx=18,pady=(18,8))
        self.camera_toggle=ctk.CTkSwitch(controls,text='Camera presence',variable=self.camera_var,command=self.toggle_camera,progress_color='#3a8c68')
        self.camera_toggle.grid(row=0,column=1,sticky='w',padx=18,pady=(18,8))
        self.startup_var=tk.BooleanVar(value=get_startup())
        self.startup_toggle=ctk.CTkSwitch(controls,text='Start with Windows',variable=self.startup_var,command=self.toggle_startup,progress_color='#3a8c68')
        self.startup_toggle.grid(row=0,column=2,sticky='w',padx=18,pady=(18,8))
        self.stop=ctk.CTkButton(controls,text='Pause all',width=94,fg_color='#33394a',command=self.pause_all)
        self.stop.grid(row=0,column=3,sticky='e',padx=18,pady=(18,8))
        self.sensor_status=ctk.CTkLabel(controls,text='MONITORING OFF  /  Screen checks every 120s when enabled',text_color=MUTED,anchor='w')
        self.sensor_status.grid(row=1,column=0,columnspan=3,sticky='ew',padx=18,pady=(0,16))
        workspace=ctk.CTkFrame(main,fg_color='transparent')
        workspace.grid(row=2,column=0,sticky='nsew'); workspace.grid_columnconfigure(0,weight=3);workspace.grid_columnconfigure(1,weight=2);workspace.grid_rowconfigure(0,weight=1)
        chat_panel=ctk.CTkFrame(workspace,fg_color=PANEL,corner_radius=14)
        chat_panel.grid(row=0,column=0,sticky='nsew',padx=(0,14)); chat_panel.grid_rowconfigure(1,weight=1);chat_panel.grid_columnconfigure(0,weight=1)
        title=ctk.CTkFrame(chat_panel,fg_color='transparent');title.grid(row=0,column=0,sticky='ew',padx=16,pady=12)
        ctk.CTkLabel(title,text='Conversation',font=('Segoe UI',16,'bold')).pack(side='left')
        self.reset=ctk.CTkButton(title,text='Clear',width=55,fg_color='#242a38',command=self.clear);self.reset.pack(side='right')
        self.chat=ctk.CTkScrollableFrame(chat_panel,fg_color='#10131b',corner_radius=10)
        self.chat.grid(row=1,column=0,sticky='nsew',padx=12,pady=(0,12))
        self.chat.grid_columnconfigure(0,weight=1); self.chat_rows=0
        self.msg_labels=[]; self.chat.bind('<Configure>',self.fit_bubbles)
        self.write('JARVIS\nVanakkam bro. What do you want to finish today? I can help with Maya practice and small next steps.\n')
        right=ctk.CTkFrame(workspace,fg_color=PANEL,corner_radius=14);right.grid(row=0,column=1,sticky='nsew');right.grid_columnconfigure(0,weight=1);right.grid_rowconfigure(3,weight=1)
        ctk.CTkLabel(right,text='Agent activity',font=('Segoe UI',16,'bold')).grid(row=0,column=0,sticky='w',padx=18,pady=(16,8))
        self.presence=ctk.CTkLabel(right,text='Camera off',text_color=MUTED,anchor='w');self.presence.grid(row=1,column=0,sticky='ew',padx=18)
        ctk.CTkLabel(right,text='Ephemeral checks. No recordings.',text_color=MUTED,font=('Segoe UI',11)).grid(row=2,column=0,sticky='w',padx=18,pady=(4,12))
        self.feed=ctk.CTkTextbox(right,fg_color=PANEL,wrap='word',font=('Segoe UI',12),height=140)
        self.feed.grid(row=3,column=0,sticky='nsew',padx=12,pady=(0,12));self.feed.configure(state='disabled')
        self.activity('Ready. Screen and camera are OFF. Enable only when your desktop is safe to view.')
        composer=ctk.CTkFrame(main,fg_color=PANEL,corner_radius=14);composer.grid(row=3,column=0,sticky='ew',pady=(16,0));composer.grid_columnconfigure(0,weight=1)
        self.input=ctk.CTkTextbox(composer,height=50,fg_color='#10131b',wrap='word',font=('Segoe UI',14),border_width=1,border_color='#2a3245')
        self.input.grid(row=0,column=0,columnspan=2,sticky='ew',padx=14,pady=(10,0))
        self.input.bind('<Return>',self.enter_send)
        self.screen=ctk.CTkButton(composer,text='Add screen context',fg_color='#242a38',command=lambda:self.ask(True));self.screen.grid(row=1,column=0,sticky='w',padx=14,pady=12)
        self.send=ctk.CTkButton(composer,text='Ask JARVIS',fg_color=ACCENT,text_color='#0d2118',hover_color='#77cc9f',command=lambda:self.ask(False));self.send.grid(row=1,column=1,sticky='e',padx=14,pady=12)
        voicebar=ctk.CTkFrame(main,fg_color='transparent')
        voicebar.grid(row=4,column=0,sticky='ew',pady=(8,0));voicebar.grid_columnconfigure(2,weight=1)
        self.mic=ctk.CTkButton(voicebar,text='Start recording',width=125,fg_color='#324356',command=self.toggle_recording)
        self.mic.grid(row=0,column=0,padx=(0,8))
        self.speech_toggle=ctk.CTkSwitch(voicebar,text='Speak replies',variable=self.speech_enabled,command=self.toggle_speech,width=125)
        self.speech_toggle.grid(row=0,column=1,padx=(0,8))
        self.voice_choice=ctk.CTkOptionMenu(voicebar,values=['Checking voices...'],width=180,fg_color='#242a38')
        self.voice_choice.grid(row=0,column=2,sticky='e',padx=(0,8))
        self.stop_speech=ctk.CTkButton(voicebar,text='Stop speech',width=100,fg_color='#33394a',command=self.stop_audio)
        self.stop_speech.grid(row=0,column=3)
        self.status=tk.StringVar(value='Ready. Start LM Studio to connect your local brain.')
        ctk.CTkLabel(main,textvariable=self.status,text_color=MUTED,anchor='w',wraplength=820).grid(row=5,column=0,sticky='ew',pady=(8,0))
        root.protocol('WM_DELETE_WINDOW',self.close)
        root.after(100,self.poll)

    def toggle_recording(self):
        if self.recording:self.finish_recording();return
        if self.busy or self.speaking:return
        if not messagebox.askokcancel('Push-to-talk / local microphone','Record up to 20 seconds from your default microphone, transcribe with bundled Whisper on CPU, then review/correct the transcript before asking the local model. No audio saved or sent online. Stop recording to finish. There is no wake word or background listening. Consent of anyone heard is required. Start recording?'):return
        try:self.recorder.start()
        except LocalError as exc:self.status.set(str(exc));return
        self.recording=True;self.voice_request=False;self.mic.configure(text='Stop recording',fg_color='#8d404c')
        for w in (self.send,self.screen,self.link,self.reset):w.configure(state='disabled')
        self.status.set('MIC ON / recording locally, maximum 20 seconds. Tap Stop recording.')
    def finish_recording(self):
        self.recording=False;self.mic.configure(text='Start recording',fg_color='#324356')
        try:audio=self.recorder.stop()
        except LocalError as exc:self.set_busy(False);self.status.set(str(exc));return
        self.worker(lambda:self.transcriber.transcribe(audio),'transcript')
        self.status.set('MIC OFF / transcribing locally on CPU...')
    def toggle_speech(self):
        if not self.speech_enabled.get():self.stop_audio();return
        if not self.voice_map:
            self.speech_enabled.set(False);self.status.set('No offline Windows SAPI voice found. Text remains available.');return
        if not messagebox.askokcancel('Enable local spoken replies','Speak model replies and mentor nudges aloud using an installed Windows offline voice. Private text could be heard by others. No cloud TTS, no Piper model download. Stop speech or disable this toggle anytime. Enable for this session?'):self.speech_enabled.set(False)
    def speak(self,text):
        if self.recording:return
        voice=self.voice_map.get(self.voice_choice.get())
        self.speaking=True;self.mic.configure(state='disabled');self.tts.speak(text,voice)
    def stop_audio(self):
        self.tts.stop();self.speaking=False
        if not self.busy:self.mic.configure(state='normal')
    def privacy(self):
        messagebox.showinfo('Local privacy','Screen: one primary-monitor frame every 120s only after session consent and while minimized. Camera: local face presence every 2s, never identity or health. No frames saved. Activity/chat only in memory. Pause all cancels future checks, but an in-flight local inference may finish before its answer is discarded. Do not monitor a shared or private desktop. Telegram is separate and not offline.')
    def nudge(self,text):
        self.activity(text)
        if self.speech_enabled.get() and not self.recording and not self.busy:self.speak(text)
        if self.root.state() != 'iconic':return
        if self.toast and self.toast.winfo_exists():self.toast.destroy()
        self.toast=ctk.CTkToplevel(self.root)
        toast=self.toast
        toast.title('JARVIS nudge');toast.geometry('380x210');toast.attributes('-topmost',True)
        ctk.CTkLabel(toast,text='JARVIS / LOCAL NUDGE',text_color=ACCENT,font=('Segoe UI',15,'bold')).pack(anchor='w',padx=20,pady=(16,6))
        ctk.CTkLabel(toast,text=text,wraplength=335,justify='left').pack(fill='both',expand=True,padx=20)
        ctk.CTkButton(toast,text='Pause all',command=lambda:(self.pause_all(),toast.destroy())).pack(side='left',padx=20,pady=14)
        ctk.CTkButton(toast,text='Dismiss',fg_color='#33394a',width=85,command=toast.destroy).pack(side='right',padx=20,pady=14)
        toast.after(20000,lambda:toast.destroy() if toast.winfo_exists() else None)
    def enter_send(self,event):
        if event.state & 0x1:return  # Shift+Enter keeps a newline
        if not self.input.get('1.0','end').strip():return 'break'
        self.ask(False)
        return 'break'
    def add_message(self,role,text):
        colors={'you':'#253d36','jarvis':'#1b2233','system':'#232838'}
        bubble=ctk.CTkFrame(self.chat,fg_color=colors[role],corner_radius=14)
        label={'you':'YOU','jarvis':'JARVIS','system':'JARVIS'}[role]
        ctk.CTkLabel(bubble,text=label,text_color='#8fd9b6' if role=='you' else ACCENT,font=('Segoe UI',10,'bold')).pack(anchor='w',padx=14,pady=(10,0))
        body=ctk.CTkLabel(bubble,text=text,wraplength=self.bubble_wrap(),justify='left',font=('Segoe UI',13))
        body.pack(anchor='w',padx=14,pady=(3,12)); self.msg_labels.append(body)
        bubble.grid(row=self.chat_rows,column=0,sticky='ew' if role=='system' else ('e' if role=='you' else 'w'),padx=40 if role=='system' else 10,pady=5)
        self.chat_rows+=1
        self.root.after(80,self.scroll_chat)
    def bubble_wrap(self):
        return max(240,self.chat.winfo_width()-110)
    def fit_bubbles(self,event):
        w=max(240,event.width-110)
        for lbl in self.msg_labels:
            try:lbl.configure(wraplength=w)
            except Exception:pass
    def scroll_chat(self):
        try:self.chat._parent_canvas.yview_moveto(1.0)
        except Exception:pass
    def write(self,text):
        if text.startswith('YOU\n'):self.add_message('you',text[4:].strip())
        elif text.startswith('JARVIS\n'):self.add_message('jarvis',text[7:].strip())
        else:self.add_message('system',text.strip())
    def toggle_startup(self):
        if not self.startup_var.get():
            try:set_startup(False);self.activity('Start with Windows disabled.')
            except LocalError as exc:self.status.set(str(exc))
            return
        if not messagebox.askokcancel('Start JARVIS with Windows?','JARVIS will open automatically when you sign in to Windows. Screen agent, camera, microphone and spoken replies still start OFF at every launch and need your consent each session. No background listening. Turn this off anytime with the same switch. Enable?'):
            self.startup_var.set(False);return
        try:set_startup(True);self.activity('Start with Windows enabled. All monitoring still starts OFF at every launch.')
        except LocalError as exc:self.startup_var.set(False);self.status.set(str(exc))
    def activity(self,text):
        self.feed.configure(state='normal');self.feed.insert('end',time.strftime('%H:%M')+'  '+text+'\n\n');self.feed.see('end');self.feed.configure(state='disabled')
        # Session activity only, bounded and never written to disk.
        if len(self.feed.get('1.0','end'))>12000:
            self.feed.configure(state='normal');self.feed.delete('1.0','15.0');self.feed.configure(state='disabled')
    def set_busy(self,value):
        self.busy=value
        if hasattr(self,'mic'):self.mic.configure(state='disabled' if value else 'normal')
        for w in (self.send,self.screen,self.link,self.reset):w.configure(state='disabled' if value else 'normal')
    def worker(self,fn,kind='answer',generation=None):
        self.set_busy(True);self.status.set('Thinking locally... monitoring never runs a second inference in parallel.')
        def run():
            try:self.events.put((kind,generation,fn()))
            except Exception as exc:self.events.put(('error',generation,str(exc) if isinstance(exc,LocalError) else 'Local operation failed. Check model or device and retry manually.'))
        threading.Thread(target=run,daemon=True).start()
    def poll(self):
        if self.closed:return
        while True:
            try:kind,generation,result=self.events.get_nowait()
            except queue.Empty:break
            if kind=='voices':
                self.voice_map={v['name']:v['id'] for v in result}
                names=list(self.voice_map)
                self.voice_choice.configure(values=names or ['No installed SAPI voice'])
                # Tamil LCID is 0x449. Prefer only a genuinely enumerated offline token.
                tamil=next((v['name'] for v in result if '449' in v['language'].lower().split(';')),None)
                self.voice_choice.set(tamil or (names[0] if names else 'No installed SAPI voice'))
                self.activity('Offline SAPI voices: '+(', '.join(names) if names else 'none detected')+'. No voice download or registry modification.')
                continue
            if kind=='speech_state':
                self.speaking=result=='Speaking locally'
                self.mic.configure(state='disabled' if self.speaking or self.busy else 'normal')
                self.status.set(result);continue
            if kind=='speech_error':
                self.speaking=False;self.mic.configure(state='disabled' if self.busy else 'normal');self.speech_enabled.set(False);self.voice_choice.configure(values=['Windows voice unavailable']);self.voice_choice.set('Windows voice unavailable');self.status.set(result);self.activity(result);continue
            if kind=='transcript':
                self.set_busy(False);self.input.delete('1.0','end');self.input.insert('1.0',result)
                self.voice_request=True;self.status.set('Transcript ready. Correct it, then Ask JARVIS. No audio saved.')
                self.activity('Voice transcript ready for your review.');continue
            if kind.startswith('camera'):
                if generation!=self.camera.serial:continue
                if kind=='camera':
                    self.presence.configure(text='Face detected (not identity)' if result else 'No face detected (not proof of absence)',text_color=ACCENT if result else MUTED)
                    if result and self.last_presence is False:self.nudge('Welcome back. Ready for one small step?')
                    self.last_presence=result
                elif kind=='camera_error':
                    self.camera_on=False;self.camera_var.set(False);self.presence.configure(text=result,text_color='#ff9a9a');self.activity(result)
                elif kind=='camera_stopped':self.camera_on=False
                self.sensor_label();continue
            self.set_busy(False)
            if kind=='error':
                self.status.set(result)
                if generation is not None:
                    if self.schedule.valid(generation):self.pause_screen();self.activity('Screen agent paused after an error. No automatic inference retry.')
                else:self.write('JARVIS\n'+result)
            elif kind=='nudge':
                answer,seconds=result
                if self.schedule.valid(generation):
                    self.status.set('Screen check finished in %.1fs. Frame discarded.'%seconds)
                    if answer.strip()!='NO_NUDGE' and self.schedule.accept_nudge(generation):self.nudge(answer[:600])
            else:
                answer,seconds=result;self.write('JARVIS\n'+answer+'\n');self.status.set('Finished in %.1fs. No screenshot stored.'%seconds)
                if self.speech_enabled.get():self.speak(answer)
        if (self.schedule.enabled or self.camera_on) and time.monotonic() >= self.next_break:
            self.next_break=time.monotonic()+2700
            self.nudge('A gentle break check: if comfortable, look away from the screen and stretch. This is a timer, not a health assessment.')
        # Do not capture the assistant itself. Only watch while minimized.
        if self.schedule.due(self.busy or self.recording or self.speaking):
            if self.root.state()=='iconic' and not (self.toast and self.toast.winfo_exists()):self.monitor_screen()
            else:self.schedule.begin();self.activity('Screen check skipped while JARVIS is open. Minimize to observe your workspace; monitoring remains visibly enabled.')
        if self.recording and time.monotonic()-self.recorder.started>=20:self.finish_recording()
        self.root.after(200,self.poll)
    def sensor_label(self):
        text='SCREEN ON (120s)' if self.schedule.enabled else 'SCREEN OFF'
        text+='  /  CAMERA ON (2s CPU checks)' if self.camera_on else '  /  CAMERA OFF'
        self.sensor_status.configure(text=text,text_color=ACCENT if self.schedule.enabled or self.camera_on else MUTED)
    def toggle_screen(self):
        if not self.screen_var.get():self.pause_screen();return
        consent=messagebox.askokcancel('Enable visible screen agent?',
            'While JARVIS is minimized, capture the primary screen once every 120 seconds and analyze it in LOCAL LM Studio. Nudges have a 10-minute cooldown. No frames are saved.\n\nAnything visible may be captured, including private content. Close private windows, pause before passwords/payment/messages, and do not enable on a shared desktop. Pause all or close JARVIS to stop. Monitoring starts OFF on every launch. Enable this session?')
        if not consent:self.screen_var.set(False);return
        self.schedule.start();self.next_break=time.monotonic()+2700;self.sensor_label();self.activity('Screen agent enabled for this session. First check in 120s after minimizing. Pause before private work.')
    def pause_screen(self):
        self.schedule.stop();self.screen_var.set(False);self.sensor_label()
    def toggle_camera(self):
        if not self.camera_var.get():self.camera.stop();self.camera_on=False;self.presence.configure(text='Camera stopping / releasing device');self.sensor_label();return
        if not messagebox.askokcancel('Enable local camera presence?',
            'Use camera 0 for local face-presence checks every 2 seconds. No video or frames saved or sent to LM Studio/Telegram. This does NOT recognize identity, emotions, health or prove absence. Lighting and angles cause errors. Enable only with consent of anyone in view. Camera light may stay on while enabled. Stop with Pause all or closing JARVIS. Enable this session?'):
            self.camera_var.set(False);return
        if not self.camera.start():
            self.camera_var.set(False);self.activity('Previous camera session is still releasing. Try again in a moment.');return
        self.camera_on=True;self.next_break=time.monotonic()+2700;self.sensor_label();self.presence.configure(text='Camera starting...');self.activity('Camera presence enabled locally. No recordings.')
    def pause_all(self):
        self.recorder.cancel();self.recording=False;self.mic.configure(text='Start recording',fg_color='#324356');self.speech_enabled.set(False);self.stop_audio();self.set_busy(self.busy);self.pause_screen();self.camera.stop();self.camera_on=False;self.camera_var.set(False);self.presence.configure(text='Camera stopping / releasing device');self.sensor_label();self.activity('All sensors and spoken replies OFF. Mic released. In-flight inference may finish locally; screen nudge discarded.')
    def monitor_screen(self):
        generation=self.schedule.begin()
        def analyze():
            if not self.schedule.valid(generation):return ('NO_NUDGE',0)
            image=screenshot()
            if not self.schedule.valid(generation):return ('NO_NUDGE',0)
            return self.client.ask(SCREEN_PROMPT,image,remember=False)
        self.worker(analyze,'nudge',generation)
    def ask(self,use_screen):
        if self.busy or self.recording or self.speaking:return
        text=self.input.get('1.0','end').strip()
        if not text:messagebox.showinfo('Question needed','Type a question first, bro.');return
        if use_screen:
            if not messagebox.askokcancel('Close private screens','Capture the primary monitor once for LOCAL LM Studio? Close private windows first. You will review the image next.'):return
            self.root.withdraw();self.root.after(400,lambda:self.capture_preview(text))
        else:self.submit(text,None)
    def capture_preview(self,text):
        try:image=screenshot()
        except Exception:
            self.root.deiconify();messagebox.showerror('Capture failed','An unlocked interactive desktop and screen permission are required.');return
        self.root.deiconify()
        from PIL import Image,ImageTk
        dialog=ctk.CTkToplevel(self.root);dialog.title('Review screen context');dialog.after(100,dialog.grab_set)
        pic=Image.open(io.BytesIO(image));pic.thumbnail((780,460));photo=ImageTk.PhotoImage(pic)
        label=tk.Label(dialog,image=photo,bg=BG);label.image=photo;label.pack(padx=16,pady=16)
        ctk.CTkLabel(dialog,text='This image goes only to your local model. No image saved.').pack(padx=16)
        def confirm():dialog.destroy();self.submit(text,image)
        ctk.CTkButton(dialog,text='Use locally',command=confirm).pack(side='left',padx=16,pady=16)
        ctk.CTkButton(dialog,text='Cancel',fg_color='#33394a',command=dialog.destroy).pack(side='right',padx=16,pady=16)
    def submit(self,text,image):
        self.write('YOU\n'+text+('  [local screen context]' if image else '')+'\n');self.input.delete('1.0','end');self.worker(lambda:self.client.ask(text,image))
    def check_server(self):self.worker(lambda:('Available local models: '+', '.join(self.client.models()),0))
    def clear(self):
        self.client.clear()
        for w in self.chat.winfo_children():w.destroy()
        self.chat_rows=0; self.msg_labels=[]
        self.status.set('Session cleared. No chat log saved.')
    def close(self):
        self.closed=True;self.recorder.cancel();self.tts.close();self.schedule.stop();self.camera.stop();self.root.destroy()

if __name__=='__main__':
    root=ctk.CTk()
    try:App(root)
    except Exception as exc:messagebox.showerror('Startup stopped',str(exc));root.destroy()
    else:
        if os.environ.get('JARVIS_SMOKE_TEST')=='1':
            def smoke():
                from PIL import ImageGrab
                root.update();ImageGrab.grab(bbox=(root.winfo_rootx(),root.winfo_rooty(),root.winfo_rootx()+root.winfo_width(),root.winfo_rooty()+root.winfo_height())).save(os.environ['JARVIS_SMOKE_OUTPUT']);root.destroy()
            root.after(1500,smoke)
        root.mainloop()
