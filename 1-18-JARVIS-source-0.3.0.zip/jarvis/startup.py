"""Opt-in launch at Windows sign-in. Default OFF; writes only on explicit consent."""
import os
import sys
from core import LocalError

RUN_KEY = r'Software\Microsoft\Windows\CurrentVersion\Run'
VALUE = 'JARVIS'

def get_startup():
    if os.name != 'nt':
        return False
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as key:
            winreg.QueryValueEx(key, VALUE)
            return True
    except OSError:
        return False

def set_startup(enabled):
    if os.name != 'nt':
        raise LocalError('Start with Windows is only available on Windows.')
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
        if enabled:
            winreg.SetValueEx(key, VALUE, 0, winreg.REG_SZ, '"%s"' % sys.executable)
        else:
            try:
                winreg.DeleteValue(key, VALUE)
            except OSError:
                pass
