[Setup]
AppId={{86D332D0-628A-4C72-9534-2C1B43D9F381}
AppName=JARVIS
AppVersion=0.3.0
AppPublisher=Prithiv
DefaultDirName={localappdata}\Programs\JARVIS
DefaultGroupName=JARVIS
PrivilegesRequired=lowest
OutputDir=installer-output
OutputBaseFilename=JARVIS-Setup-0.3.0
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\JARVIS.exe
[Files]
Source: "dist\JARVIS\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "config.example.json"; DestDir: "{app}"; DestName: "config.json"; Flags: onlyifdoesntexist
Source: "notes.example.txt"; DestDir: "{app}"; DestName: "notes.txt"; Flags: onlyifdoesntexist
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion
[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueName: "JARVIS"; Flags: uninsdeletevalue
[Icons]
Name: "{group}\JARVIS"; Filename: "{app}\JARVIS.exe"
Name: "{autodesktop}\JARVIS"; Filename: "{app}\JARVIS.exe"
[Run]
Filename: "{app}\JARVIS.exe"; Description: "Open JARVIS"; Flags: nowait postinstall skipifsilent
