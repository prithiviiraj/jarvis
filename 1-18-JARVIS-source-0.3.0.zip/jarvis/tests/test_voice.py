import queue
import unittest
from unittest.mock import Mock,patch
import sys,types
from voice import Recorder,Transcriber,WindowsSpeech
from core import LocalError
class TestVoice(unittest.TestCase):
    def test_model_missing_does_not_download(self):
        with self.assertRaises(LocalError):Transcriber('/missing/local/model').transcribe(None)
    def test_record_cancel_releases_device(self):
        r=Recorder();r.active=True;r.frames=[1];r.stream=Mock();stream=r.stream
        r.cancel();self.assertFalse(r.active);self.assertEqual(r.frames,[]);stream.abort.assert_called_once();stream.close.assert_called_once()
    def test_missing_device_safe_error(self):
        r=Recorder()
        with patch.dict(sys.modules,{'sounddevice':types.SimpleNamespace(InputStream=Mock(side_effect=RuntimeError('private device details')))}):
            with self.assertRaisesRegex(LocalError,'Microphone unavailable'):r.start()
        self.assertFalse(r.active);self.assertIsNone(r.stream)
    def test_no_audio(self):
        with self.assertRaisesRegex(LocalError,'No microphone audio'):Recorder().stop()
    def test_transcribe_uses_local_model(self):
        t=Transcriber('/missing');t.model=Mock();segment=Mock();segment.text='  Hello bro '
        t.model.transcribe.return_value=([segment],None)
        self.assertEqual(t.transcribe([1]),'Hello bro')
        self.assertTrue(t.model.transcribe.call_args.kwargs['vad_filter'])
