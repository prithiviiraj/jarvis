"""Enumerate actual offline voices on Windows runner; not owner laptop proof."""
import json,sys
from pathlib import Path
import pythoncom,win32com.client
pythoncom.CoInitialize()
v=win32com.client.Dispatch('SAPI.SpVoice');tokens=v.GetVoices()
data=[{'name':tokens.Item(i).GetDescription(),'language':tokens.Item(i).GetAttribute('Language')} for i in range(tokens.Count)]
print(json.dumps(data))
Path('dist').mkdir(exist_ok=True)
Path('dist/windows-voices.json').write_text(json.dumps(data,indent=2))
v.Speak('JARVIS local voice test.',1|16)
if not v.WaitUntilDone(10000):v.Speak('',2);raise RuntimeError('Local TTS did not finish')
pythoncom.CoUninitialize()
