import sys,types,threading,unittest
from unittest.mock import Mock,patch
from core import Client,LocalError,extract_text
import startup

def client_stub():
    c=Client.__new__(Client);c.model='test-model';c.history=[];c.lock=threading.Lock();return c

class TestEmptyReply(unittest.TestCase):
    def test_list_content(self):
        self.assertEqual(extract_text({'choices':[{'message':{'content':[{'type':'text','text':'  vanakkam '}]}}]}),'vanakkam')
    def test_malformed(self):
        self.assertIsNone(extract_text({}));self.assertIsNone(extract_text({'choices':[{'message':{'content':None}}]}))
    def test_empty_then_ok_retries_once(self):
        c=client_stub()
        c.request=Mock(side_effect=[{'choices':[{'message':{'content':''}}]},{'choices':[{'message':{'content':'second try'}}]}])
        answer,_=c.ask('hello')
        self.assertEqual(answer,'second try');self.assertEqual(c.request.call_count,2)
    def test_persistent_empty_honest_error(self):
        c=client_stub();c.request=Mock(return_value={'choices':[{'message':{'content':'  '}}]})
        with self.assertRaisesRegex(LocalError,'ask again'):c.ask('hello')
        self.assertEqual(c.request.call_count,2)

class TestStartup(unittest.TestCase):
    def test_non_windows(self):
        with patch.object(startup.os,'name','posix'):
            self.assertFalse(startup.get_startup())
            with self.assertRaises(LocalError):startup.set_startup(True)
    def test_windows_set_read_remove(self):
        store={}
        key=Mock();key.__enter__=Mock(return_value=key);key.__exit__=Mock(return_value=False)
        def query(k,n):
            if n not in store:raise FileNotFoundError(n)
            return store[n],1
        fake=types.SimpleNamespace(HKEY_CURRENT_USER=1,KEY_SET_VALUE=0,REG_SZ=1,
            OpenKey=Mock(return_value=key),
            SetValueEx=lambda k,n,t,ty,v:store.__setitem__(n,v),
            DeleteValue=lambda k,n:store.pop(n,None),QueryValueEx=query)
        with patch.object(startup.os,'name','nt'),patch.dict(sys.modules,{'winreg':fake}):
            self.assertFalse(startup.get_startup())
            startup.set_startup(True);self.assertIn('JARVIS',store);self.assertTrue(startup.get_startup())
            startup.set_startup(False);self.assertFalse(startup.get_startup())
