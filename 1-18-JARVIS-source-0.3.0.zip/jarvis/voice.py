"""Local push-to-talk audio. No cloud fallback, wake word or audio files."""
import os
import queue
import threading
import time
from pathlib import Path
from core import LocalError

class Recorder:
    def __init__(self, max_seconds=20):
        self.max_seconds=max_seconds
        self.stream=None
        self.frames=[]
        self.rate=16000
        self.lock=threading.Lock()
        self.active=False
        self.error=False
        self.samples=0
        self.started=0
    def start(self):
        import sounddevice as sd
        with self.lock:
            if self.active:raise LocalError('Microphone is already recording.')
            self.frames=[];self.samples=0;self.error=False;self.active=True
            self.started=time.monotonic()
        def callback(data,frames,when,status):
            with self.lock:
                if not self.active:return
                if status:self.error=True
                remaining=int(self.rate*self.max_seconds)-self.samples
                if remaining>0:
                    chunk=data[:remaining,0].copy()
                    self.frames.append(chunk);self.samples+=len(chunk)
        try:
            self.stream=sd.InputStream(samplerate=self.rate,channels=1,dtype='float32',callback=callback)
            self.stream.start()
        except Exception:
            self.cancel()
            raise LocalError('Microphone unavailable. Check Windows mic permission and your default input device.') from None
    def stop(self):
        import numpy as np
        with self.lock:
            self.active=False
        if self.stream:
            try:self.stream.stop();self.stream.close()
            finally:self.stream=None
        with self.lock:
            frames=self.frames;self.frames=[]
            error=self.error
        if error:raise LocalError('Microphone buffer issue. Recording discarded. Try again without other audio apps.')
        if not frames:raise LocalError('No microphone audio was captured.')
        return np.concatenate(frames)
    def cancel(self):
        with self.lock:self.active=False;self.frames=[]
        if self.stream:
            try:self.stream.abort();self.stream.close()
            except Exception:pass
            self.stream=None

class Transcriber:
    def __init__(self, model_dir):
        self.path=Path(model_dir)
        self.model=None
    def transcribe(self,audio,language=None):
        if self.model is None:
            if not (self.path/'model.bin').exists():
                raise LocalError('Bundled Whisper base model is missing. Reinstall the complete voice build. No online download was attempted.')
            from faster_whisper import WhisperModel
            self.model=WhisperModel(str(self.path),device='cpu',compute_type='int8',cpu_threads=4,num_workers=1,local_files_only=True)
        # ndarray passed directly; no recording file written.
        segments,info=self.model.transcribe(audio,language=language,beam_size=1,vad_filter=True,condition_on_previous_text=False)
        text=' '.join(segment.text.strip() for segment in segments).strip()
        if not text:raise LocalError('No clear speech found. Try again or type the question.')
        return text

class WindowsSpeech:
    """Replaceable TTS interface. Uses installed SAPI voices, no asset bundling."""
    def __init__(self, events):
        self.events=events
        self.commands=queue.Queue()
        self.cancelled=threading.Event()
        self.voices=[]
        self.generation=0
        self.thread=threading.Thread(target=self.run,daemon=True)
        self.thread.start()
    def speak(self,text,voice_id=None):
        self.stop()
        self.commands.put(('speak',text[:3000],voice_id,self.generation))
    def stop(self):
        self.generation+=1
        self.cancelled.set()
        # Drop queued speech, never replay stale nudges.
        while True:
            try:self.commands.get_nowait()
            except queue.Empty:break
    def close(self):
        self.stop();self.commands.put(('close','',None,self.generation))
    def run(self):
        try:
            if os.name!='nt':raise RuntimeError()
            import pythoncom
            import win32com.client
            pythoncom.CoInitialize()
            speaker=win32com.client.Dispatch('SAPI.SpVoice')
            tokens=speaker.GetVoices()
            entries=[]
            for i in range(tokens.Count):
                token=tokens.Item(i)
                entries.append({'id':token.Id,'name':token.GetDescription(),'language':token.GetAttribute('Language')})
            self.voices=entries
            self.events.put(('voices',None,entries))
            while True:
                kind,text,voice_id,generation=self.commands.get()
                if generation!=self.generation:continue
                if kind=='close':break
                self.cancelled.clear()
                if voice_id:
                    for i in range(tokens.Count):
                        if tokens.Item(i).Id==voice_id:speaker.Voice=tokens.Item(i);break
                self.events.put(('speech_state',None,'Speaking locally'))
                # Async, plain text (not SSML): external/model text cannot become markup.
                speaker.Speak(text,1|16)
                while not speaker.WaitUntilDone(50):
                    if self.cancelled.is_set() or generation!=self.generation:speaker.Speak('',2);break
                self.events.put(('speech_state',None,'Speech stopped' if self.cancelled.is_set() else 'Speech finished'))
            speaker.Speak('',2)
            pythoncom.CoUninitialize()
        except Exception:
            self.events.put(('speech_error',None,'Offline Windows speech unavailable. Text still works; no cloud voice used.'))
