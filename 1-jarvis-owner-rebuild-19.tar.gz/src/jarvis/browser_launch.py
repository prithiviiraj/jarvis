"""Plain desktop browser launch. Opening the app is not browser control:
no automation channel, no page access, no review pipeline."""
import os, re, subprocess, sys
from pathlib import Path

def _candidates():
    pf = os.environ.get('ProgramFiles', 'C:\\Program Files')
    pfx = os.environ.get('ProgramFiles(x86)', 'C:\\Program Files (x86)')
    local = os.environ.get('LOCALAPPDATA', '')
    return [
        ('Brave', [pfx + '\\BraveSoftware\\Brave-Browser\\Application\\brave.exe',
                   pf + '\\BraveSoftware\\Brave-Browser\\Application\\brave.exe',
                   local + '\\BraveSoftware\\Brave-Browser\\Application\\brave.exe']),
        ('Chrome', [pf + '\\Google\\Chrome\\Application\\chrome.exe',
                    pfx + '\\Google\\Chrome\\Application\\chrome.exe',
                    local + '\\Google\\Chrome\\Application\\chrome.exe']),
        ('Edge', [pfx + '\\Microsoft\\Edge\\Application\\msedge.exe',
                  pf + '\\Microsoft\\Edge\\Application\\msedge.exe']),
    ]

def installed():
    found = []
    for name, paths in _candidates():
        for path in paths:
            if path and Path(path).is_file():
                found.append((name, path))
                break
    return found

_PREFIX = r'^\s*(?:(?:hey|hi|hello|ok|okay)\s+)?(?:(?:jarvis|j\.a\.r\.v\.i\.s\.?|lyra|dex)[, :]+)?\s*'
_BARE = re.compile(_PREFIX + r'(brave|chrome|edge|browser)\s*[.!?]*\s*$', re.I)
_PLAIN = re.compile(_PREFIX + r'(?:please\s+)?(?:open|launch|start)\s+(?:the\s+|my\s+)?(brave|chrome|edge|(?:web\s+)?browser)?\s*((?:https?://)?[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:/\S*)?)?\s*(?:in\s+(brave|chrome|edge))?\s*[.!?]*\s*$', re.I)

def open_intent(text):
    """Parse plain app-launch requests only ('open brave', 'open google.com in chrome').
    Compound browser commands return None and stay with the reviewed control pipeline."""
    if not isinstance(text, str):
        return None
    m = _BARE.match(text) or _PLAIN.match(text)
    if not m:
        return None
    name = ''
    url = None
    for group in m.groups():
        if not group:
            continue
        word = group.lower().replace('web ', '')
        if word in ('brave', 'chrome', 'edge', 'browser') and not name:
            name = word
        elif re.fullmatch(r'(?:https?://)?[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:/\S*)?', group, re.I):
            url = group if group.lower().startswith('http') else 'https://' + group
    preferred = {'brave': 'Brave', 'chrome': 'Chrome', 'edge': 'Edge'}.get(name)
    return preferred, url

def launch(preferred=None, url=None):
    if sys.platform != 'win32':
        raise RuntimeError('Browser launch works on Windows only.')
    choices = installed()
    if not choices:
        raise RuntimeError('No installed browser found. Looked for Brave, Chrome and Edge in their standard install folders.')
    pick = None
    if preferred:
        pick = next((c for c in choices if c[0] == preferred), None)
        if pick is None:
            raise RuntimeError(preferred + ' is not installed. Found: ' + ', '.join(name for name, _ in choices) + '.')
    else:
        pick = choices[0]
    argv = [pick[1]]
    if url:
        argv.append(url)
    subprocess.Popen(argv, close_fds=True)
    return pick[0]
