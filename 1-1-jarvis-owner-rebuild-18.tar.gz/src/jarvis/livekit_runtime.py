"""Offline voice-to-voice runtime: local LiveKit server + JARVIS voice worker.

Both are bundled next to the frozen executable under a livekit/ folder. The
server is the official LiveKit Windows binary run with --dev (localhost only);
the worker is the frozen modern-ui/livekit_agent.py chain (bundled whisper STT,
LM Studio LLM, bundled Kokoro TTS). No cloud traffic. Tokens are dev-signed
HS256 JWTs minted locally with the well-known dev key/secret the server uses.
"""
import base64, hashlib, hmac, json, os, socket, subprocess, sys, threading, time
from collections import deque
from pathlib import Path

DEV_KEY = 'devkey'
DEV_SECRET = 'secret'
URL = 'ws://127.0.0.1:7880'
ROOM = 'jarvis'
HOST, PORT = '127.0.0.1', 7880


def _b64(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode()


def mint_token(identity='owner-ui', name='Owner', ttl=3600):
    """Dev HS256 access token matching livekit-server --dev key/secret."""
    now = int(time.time())
    header = {'alg': 'HS256', 'typ': 'JWT'}
    payload = {
        'iss': DEV_KEY, 'sub': identity, 'iat': now, 'nbf': now - 10, 'exp': now + ttl,
        'name': name,
        'video': {'roomJoin': True, 'room': ROOM, 'canPublish': True, 'canSubscribe': True},
    }
    head = _b64(json.dumps(header, separators=(',', ':')).encode())
    body = _b64(json.dumps(payload, separators=(',', ':')).encode())
    sig = hmac.new(DEV_SECRET.encode(), (head + '.' + body).encode(), hashlib.sha256).digest()
    return head + '.' + body + '.' + _b64(sig)


def _port_open(timeout=0.4):
    try:
        with socket.create_connection((HOST, PORT), timeout=timeout):
            return True
    except OSError:
        return False


class LiveKitRuntime:
    def __init__(self):
        self.state = 'off'          # off|starting|server-up|ready|error
        self.error = ''
        self.model = ''
        self.logs = deque(maxlen=40)
        self._server = None
        self._worker = None
        self._lock = threading.RLock()
        self._started_at = 0.0

    def assets_dir(self):
        override = os.environ.get('JARVIS_LIVEKIT_DIR')
        if override:
            return Path(override)
        if getattr(sys, 'frozen', False):
            return Path(sys.executable).resolve().parent / 'livekit'
        return Path(os.environ.get('JARVIS_LIVEKIT_DIR', '')) if os.environ.get('JARVIS_LIVEKIT_DIR') else None

    def available(self):
        folder = self.assets_dir()
        if not folder:
            return False
        server = folder / ('livekit-server.exe' if os.name == 'nt' else 'livekit-server')
        worker = folder / ('jarvis-livekit-agent.exe' if os.name == 'nt' else 'jarvis-livekit-agent')
        return server.is_file() and worker.is_file()

    def _spawn(self, argv, **kw):
        flags = {}
        if os.name == 'nt':
            flags['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        return subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, errors='replace', **flags, **kw)

    def _models_ready(self):
        try:
            from .paths import data_root
            return (data_root() / 'models' / 'whisper-base').is_dir() and (data_root() / 'models' / 'voices' / 'model.onnx').is_file()
        except Exception:
            return False

    def start(self, wait_models=True):
        with self._lock:
            if self.state in ('starting', 'server-up', 'ready'):
                return
            if not self.available():
                self.state = 'error'
                self.error = 'Bundled live voice runtime is not installed with this build.'
                return
            self.state = 'starting'
            self.error = ''
        threading.Thread(target=self._run, args=(wait_models,), daemon=True).start()

    def _run(self, wait_models):
        try:
            folder = self.assets_dir()
            server = folder / ('livekit-server.exe' if os.name == 'nt' else 'livekit-server')
            worker = folder / ('jarvis-livekit-agent.exe' if os.name == 'nt' else 'jarvis-livekit-agent')
            if not _port_open():
                self._server = self._spawn([str(server), '--dev', '--bind', HOST, '--port', str(PORT)])
                deadline = time.monotonic() + 15
                while time.monotonic() < deadline and not _port_open():
                    if self._server.poll() is not None:
                        raise RuntimeError('Local voice server exited during start.')
                    time.sleep(0.25)
                if not _port_open():
                    raise RuntimeError('Local voice server did not open its port.')
            with self._lock:
                self.state = 'server-up'
            if wait_models:
                deadline = time.monotonic() + 180
                while time.monotonic() < deadline and not self._models_ready():
                    time.sleep(1.0)
            if not self._models_ready():
                raise RuntimeError('Bundled speech models are not imported yet; voice worker not started.')
            self._worker = self._spawn([str(worker), '--url', URL, '--room', ROOM,
                                        '--api-key', DEV_KEY, '--api-secret', DEV_SECRET])
            self._started_at = time.monotonic()
            threading.Thread(target=self._read_worker, daemon=True).start()
        except Exception as exc:
            with self._lock:
                self.state = 'error'
                self.error = str(exc)[:240]
            self._kill()

    def _read_worker(self):
        proc = self._worker
        try:
            for line in proc.stdout:
                line = line.strip()
                if not line:
                    continue
                with self._lock:
                    self.logs.append(line[:400])
                try:
                    event = json.loads(line)
                except ValueError:
                    continue
                kind = event.get('kind')
                if kind == 'ready':
                    with self._lock:
                        self.state = 'ready'
                elif kind == 'error':
                    with self._lock:
                        self.state = 'error'
                        self.error = str(event.get('error', 'Voice worker error'))[:240]
                elif kind == 'status' and 'Brain connected:' in str(event.get('text', '')):
                    with self._lock:
                        self.model = str(event.get('text')).split('Brain connected:', 1)[1].strip()
        except Exception:
            pass
        finally:
            code = proc.poll()
            with self._lock:
                if self.state not in ('off',) and code is not None and self.state != 'error':
                    self.state = 'error'
                    self.error = 'Voice worker stopped unexpectedly (exit %s).' % code

    def _kill(self):
        for proc in (self._worker, self._server):
            try:
                if proc and proc.poll() is None:
                    proc.terminate()
            except Exception:
                pass
        self._worker = self._server = None

    def stop(self):
        with self._lock:
            self.state = 'off'
            self.error = ''
        self._kill()

    def token(self):
        if self.state not in ('server-up', 'ready'):
            return None
        return {'url': URL, 'room': ROOM, 'token': mint_token()}

    def snapshot(self):
        with self._lock:
            live = self.state in ('server-up', 'ready')
            return {'available': self.available(), 'state': self.state, 'error': self.error,
                    'model': self.model, 'url': URL if live else '', 'room': ROOM,
                    'token': mint_token() if live else '',
                    'log': list(self.logs)[-20:]}
