import {Room, RoomEvent, Track, ConnectionState} from 'livekit-client';

export type LiveHandlers = {
  onState?:(state:string)=>void;
  onSpeaking?:(speaking:boolean)=>void;
  onError?:(message:string)=>void;
};

// One local LiveKit session: WebRTC mic publish + agent audio playback.
// Everything stays on this laptop against the bundled livekit-server.
export class LiveVoice {
  private room:Room|null = null;
  private handlers:LiveHandlers;
  private audioEls:HTMLAudioElement[] = [];

  constructor(handlers:LiveHandlers){this.handlers = handlers;}

  get connected(){return this.room !== null && this.room.state === ConnectionState.Connected;}

  async connect(url:string, token:string){
    if(this.connected) return;
    await this.disconnect();
    const room = new Room();
    this.room = room;
    room.on(RoomEvent.ConnectionStateChanged, (s)=>this.handlers.onState?.(String(s)));
    room.on(RoomEvent.Disconnected, ()=>this.handlers.onState?.('disconnected'));
    room.on(RoomEvent.TrackSubscribed, (track)=>{
      if(track.kind === Track.Kind.Audio){
        const el = track.attach();
        this.audioEls.push(el);
        void el.play().catch(()=>{});
      }
    });
    room.on(RoomEvent.TrackUnsubscribed, (track)=>{
      track.detach().forEach((el)=>el.remove());
    });
    room.on(RoomEvent.ActiveSpeakersChanged, (speakers)=>{
      this.handlers.onSpeaking?.(speakers.some((p)=>p.identity === 'jarvis-voice-worker'));
    });
    try{
      await room.connect(url, token);
      await room.localParticipant.setMicrophoneEnabled(true);
    }catch(err){
      await this.disconnect();
      throw err;
    }
  }

  async disconnect(){
    this.audioEls.forEach((el)=>el.remove());
    this.audioEls = [];
    const room = this.room;
    this.room = null;
    if(room){
      try{await room.localParticipant.setMicrophoneEnabled(false);}catch{/* closing anyway */}
      await room.disconnect();
    }
  }
}
