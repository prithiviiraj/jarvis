"""JARVIS offline voice-to-voice worker (LiveKit Agents).

Fully local chain on the owner's laptop: LiveKit server on localhost (WebRTC
transport, VAD, turn-taking, barge-in) + faster-whisper STT (bundled model) +
LM Studio LLM (OpenAI-compatible, localhost) + Kokoro TTS (bundled assets).
No cloud calls. Prints JSON lines on stdout for the bridge (transcripts/state).
"""
import argparse, asyncio, json, os, sys, time, traceback
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

def log(obj):
    print(json.dumps({'livekit': True, **obj}), flush=True)

# ---------------- STT: bundled faster-whisper ----------------
from livekit.agents import stt, tts
from livekit import rtc

class WhisperSTT(stt.STT):
    def __init__(self, model_path, device='cpu', compute='int8', language=None):
        super().__init__(capabilities=stt.STTCapabilities(streaming=False, interim_results=False))
        from faster_whisper import WhisperModel
        self._model = WhisperModel(str(model_path), device=device,
                                   compute_type=compute, cpu_threads=4, num_workers=1,
                                   local_files_only=True)
        self._language = language

    @property
    def model(self): return 'faster-whisper-bundled'
    @property
    def provider(self): return 'JARVIS local'

    async def _recognize_impl(self, buffer, *, language=None, conn_options=None):
        import numpy as np
        frame = rtc.combine_audio_frames(buffer)
        if frame.sample_rate != 16000 or frame.num_channels != 1:
            resampler = rtc.AudioResampler(frame.sample_rate, 16000, num_channels=frame.num_channels,
                                           quality=rtc.AudioResamplerQuality.QUALITY_HIGH)
            frames = resampler.push(frame) + resampler.flush()
            frame = rtc.combine_audio_frames(frames)
        data = np.frombuffer(frame.data, dtype=np.int16).astype(np.float32) / 32768.0
        segments, info = await asyncio.get_event_loop().run_in_executor(
            None, lambda: self._model.transcribe(data, beam_size=1,
                                                 language=language or self._language,
                                                 vad_filter=False))
        segs = list(segments)
        text = ' '.join(s.text for s in segs).strip()
        return stt.SpeechEvent(
            type=stt.SpeechEventType.FINAL_TRANSCRIPT,
            alternatives=[stt.SpeechData(text=text, language=info.language or self._language or 'en')])

# ---------------- TTS: bundled Kokoro ----------------
from livekit.agents.types import DEFAULT_API_CONNECT_OPTIONS

class KokoroTTS(tts.TTS):
    def __init__(self, synth):
        super().__init__(capabilities=tts.TTSCapabilities(streaming=False),
                         sample_rate=24000, num_channels=1)
        self._synth = synth

    @property
    def model(self): return 'kokoro-bundled'
    @property
    def provider(self): return 'JARVIS local'

    def synthesize(self, text, *, conn_options=None):
        return _KokoroChunked(tts=self, input_text=text,
                              conn_options=conn_options or DEFAULT_API_CONNECT_OPTIONS)

class _KokoroChunked(tts.ChunkedStream):
    async def _run(self, output_emitter):
        import numpy as np
        from livekit.agents.utils import shortuuid
        output_emitter.initialize(request_id=shortuuid(),
                                  sample_rate=self._tts.sample_rate,
                                  num_channels=1, mime_type='audio/pcm', stream=False)
        loop = asyncio.get_event_loop()
        chunks = await loop.run_in_executor(
            None, lambda: list(_stream_impl(self._tts._synth, self._input_text)))
        for _part, audio, sr in chunks:
            pcm = (np.clip(audio, -1, 1) * 32767).astype(np.int16).tobytes()
            output_emitter.push(pcm)
        output_emitter.flush()

def _stream_impl(synth, text):
    # route KokoroSynth.synthesize_stream through a thread: it is a blocking generator
    import queue, threading
    q = queue.Queue()
    def run():
        try:
            for item in synth.synthesize_stream(text):
                q.put(item)
        except Exception as e:
            q.put(e)
        finally:
            q.put(None)
    threading.Thread(target=run, daemon=True).start()
    while True:
        item = q.get()
        if item is None: break
        if isinstance(item, Exception): raise item
        yield item


# ---------------- Worker main ----------------
async def run(args):
    from livekit import agents, api
    from livekit.plugins import openai as lk_openai, silero

    # Bundled JARVIS assets
    from jarvis.paths import ensure_layout
    from jarvis.native_frontend import verified_frontend
    from jarvis.experimental.kokoro import NativeG2P, KokoroSynth

    cache = ensure_layout() / 'models'
    assets = cache / 'voices'
    whisper_dir = cache / args.whisper
    if not whisper_dir.is_dir():
        log({'kind': 'error', 'where': 'stt-assets', 'error': 'Bundled speech model missing: ' + str(whisper_dir)})
        return 2
    exe, data = verified_frontend()
    g2p = NativeG2P(exe, data)
    synth = KokoroSynth(assets / 'model.onnx', assets / (args.voice + '.bin'), assets / 'config.json', g2p)

    # LM Studio: auto-pick the loaded chat model
    import urllib.request
    try:
        with urllib.request.urlopen(args.lm_url.rstrip('/v1') + '/api/v0/models', timeout=5) as r:
            payload = json.loads(r.read())
        loaded = [m for m in payload.get('models', []) if (m.get('loaded_instances') or [])]
        chat = [m for m in loaded if m.get('type') in ('llm', 'vlm')] or loaded
        model_id = chat[0]['id']
    except Exception as e:
        log({'kind': 'error', 'where': 'lm-studio', 'error': 'LM Studio not reachable or no model loaded. Open LM Studio and load one chat model. (' + str(e) + ')'})
        return 3
    log({'kind': 'status', 'text': 'Brain connected: ' + model_id})

    vad = silero.VAD.load()
    session = agents.AgentSession(
        vad=vad,
        stt=stt.StreamAdapter(stt=WhisperSTT(whisper_dir, device=args.stt_device), vad=vad),
        llm=lk_openai.LLM(model=model_id, base_url=args.lm_url, api_key='lm-studio', timeout=30),
        tts=KokoroTTS(synth),
        allow_interruptions=True,
    )

    @session.on('conversation_item_added')
    def _item(ev):
        item = ev.item
        role = getattr(item, 'role', '')
        text = ''
        try:
            text = item.text_content or ''
        except Exception:
            pass
        if role in ('user', 'assistant') and text:
            log({'kind': 'you' if role == 'user' else 'jarvis', 'text': text})

    agent = agents.Agent(instructions=(
        'You are JARVIS, the owner\'s direct voice teammate. Reply briefly and naturally, '
        'like speech, not like a document. One or two short sentences unless he asks for more. '
        'Be proactive: answer first, act when asked, never narrate menus or settings. '
        'He speaks English and Tanglish; understand both, reply in his language.'))

    token = (api.AccessToken(args.api_key, args.api_secret)
             .with_identity('jarvis-voice-worker')
             .with_grants(api.VideoGrants(room_join=True, room=args.room)))
    room = rtc.Room()
    await room.connect(args.url, token.to_jwt())
    log({'kind': 'status', 'text': 'Voice worker connected to local room ' + args.room})
    await session.start(agent=agent, room=room)
    log({'kind': 'ready'})
    stop = asyncio.Event()
    try:
        await stop.wait()
    finally:
        await session.aclose()
        await room.disconnect()
        g2p.close()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--url', default='ws://127.0.0.1:7880')
    p.add_argument('--room', default='jarvis')
    p.add_argument('--api-key', default='devkey')
    p.add_argument('--api-secret', default='secret')
    p.add_argument('--lm-url', default='http://127.0.0.1:1234/v1')
    p.add_argument('--whisper', default='whisper-base')
    p.add_argument('--voice', default='am_puck')
    p.add_argument('--stt-device', default='cpu')
    args = p.parse_args()
    try:
        raise SystemExit(asyncio.run(run(args)) or 0)
    except Exception:
        log({'kind': 'error', 'where': 'worker', 'error': traceback.format_exc(limit=3)})
        raise SystemExit(1)

if __name__ == '__main__':
    main()
