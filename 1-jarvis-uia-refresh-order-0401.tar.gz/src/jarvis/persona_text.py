"""Speaker identity comes from routing, never from model-generated labels."""
import re
from .personas import ROLES
_TAG=re.compile(r'^\s*\[('+'|'.join(ROLES)+r')\]\s*[:.\-]?\s*',re.I)
def strip_speaker_tag(text):
    """Remove leading model-invented [PERSONA] labels; keep all other bracket text."""
    if not isinstance(text,str):return text
    tag=re.compile(r'^\s*\[('+'|'.join(re.escape(n)for n in ROLES)+r')\]\s*[:.\-]?\s*',re.I)
    previous=None
    while previous!=text:
        previous=text;text=tag.sub('',text,count=1)
    return text
class SpokenTextFilter:
    """Streaming-safe removal of [bracketed asides] from speech only. Display keeps them."""
    def __init__(self):self.buffer='';self.hidden=False;self.total=0
    def feed(self,text,final=False):
        if not isinstance(text,str):raise ValueError('Text required')
        self.total+=len(text)
        if self.total>1000000:raise ValueError('Response too large')
        self.buffer+=text;out=[]
        while self.buffer:
            if self.hidden:
                end=self.buffer.find(']')
                if end<0:
                    # An unclosed bracket at the end is an unfinished aside; never speak it.
                    if final:self.buffer=''
                    break
                self.buffer=self.buffer[end+1:];self.hidden=False;continue
            start=self.buffer.find('[')
            if start<0:out.append(self.buffer);self.buffer='';break
            out.append(self.buffer[:start]);self.buffer=self.buffer[start+1:];self.hidden=True
        return ''.join(out)
    def finish(self):return self.feed('',True)
class ReportSpeechFilter:
    """Sentence buffering prevents split report/thought labels escaping into TTS."""
    def __init__(self):self.buffer='';self.report=False
    def feed(self,text,final=False):
        self.buffer+=text;out=[]
        while self.buffer:
            if self.report or re.match(r'^\s*(?:report\s+to\s+master|report\s+for\s+master|internal\s+(?:report|thought)|thought|status\s+report)\s*[:\-]',self.buffer,re.I):
                self.report=True
                newline=self.buffer.find('\n')
                if newline<0:
                    self.buffer=''
                    if final:self.report=False
                    break
                self.buffer=self.buffer[newline+1:];self.report=False;out.append('\n');continue
            boundary=re.search(r'[.!?](?=\s|$)|\n',self.buffer)
            if boundary is None and not final:break
            end=boundary.end() if boundary else len(self.buffer)
            sentence=self.buffer[:end];self.buffer=self.buffer[end:]
            if not re.match(r'^\s*(?:report\s+to\s+master|report\s+for\s+master|internal\s+(?:report|thought)|thought|status\s+report)\s*[:\-]',sentence,re.I):out.append(sentence)
        return ''.join(out)
    def finish(self):return self.feed('',True)
def spoken_text(text):
    f=SpokenTextFilter();r=ReportSpeechFilter();return r.feed(f.feed(text)+f.finish(),True)
def spoken_chunks(chunks):
    f=SpokenTextFilter();r=ReportSpeechFilter()
    for part in chunks:
        text=r.feed(f.feed(part))
        if text:yield text
    tail=r.feed(f.finish(),True)
    if tail:yield tail

def own_reply(text,actor,context=()):
    """Reject explicit invented teammate speech, not ordinary mentions/questions."""
    if not isinstance(text,str):raise ValueError('Text required')
    for name in ROLES:
        if name==actor:continue
        n=re.escape(name)
        if re.search(r"\b(?:I am|I'm|I’m|my name is)\s+"+n+r"\b",text,re.I):
            raise ValueError('Reply claimed another profile identity')
        if re.search(r'(?:^|\n)\s*'+n+r'\s*:|\['+n+r'(?:\]|[,! :])|\b'+n+r'\s+(?:says|said|replies|replied|argues|thinks|thought|feels)\b',text,re.I):
            # Quoting an actual prior line is allowed only when the same text is present.
            if text not in str(context):raise ValueError('Another profile reply must come from its own actual route')
    return text


def speaker_context(rows,actor):
    """Project shared history for one speaker without rewriting the stored archive.

    Own replies remain assistant turns. Other speakers are explicitly quoted
    conversation data, not demonstrations of the current assistant's identity.
    """
    if actor not in ROLES:raise ValueError('Unknown profile')
    out=[]
    for row in rows:
        item=dict(row);content=item.get('content')
        if item.get('role')=='assistant' and isinstance(content,str):
            match=_TAG.match(content)
            if match and match.group(1).upper()!=actor:
                name=match.group(1).upper()
                item={'role':'user','content':'Historical teammate reply, quoted context only (not a new request and not your identity): '+name+': '+content[match.end():]}
        out.append(item)
    return out
