"""Single-owner voice runtime. Headphone/half-duplex safety mode, not AEC/barge-in."""
import threading,time,uuid
from .audio import ContinuousMic
from .personas import prompt
from .persona_text import strip_speaker_tag,spoken_text,spoken_chunks,speaker_context
from .voice_feedback import safe_route,echo_reply,vision_unavailable
from .voice_feedback import runtime_device_scope
class VoiceRuntime:
    def __init__(self,vad,stt,router,speaker,notify=lambda *a:None):
        self.stt=stt;self.router=router;self.speaker=speaker;self.notify=notify
        self.cancel=threading.Event();self.streaming=False;self.reasoning_off=False;self.lock=threading.RLock();self.generation=0;self.enabled=False;self.busy=False;self.history=[];self.cloud=False;self.persona='JARVIS'
        self.turn_metrics=None;self.shared_context=None;self.record_turn=None;self.close_hook=None
        self.team_mode=False;self.vision=None;self.barge_in=False;self.fast_ack=None
        from .completion_feedback import CompletionFeedback
        self.completion_feedback=CompletionFeedback();self.pending_utterance=None;self.interrupt_capture=False
        self.mic=ContinuousMic(vad,self.on_utterance,notify)
        self.speaker.playback_event=lambda event,text,actor,sr,n:self.notify('speech-caption',{'active':event=='start','name':actor or self.persona,'text':text,'duration_s':n/sr if sr else 0,'at':time.monotonic()})
        self.speaker.output_event=self.output_event
    def poll_completion(self):
        """Use the session's one speaker between turns. Never start a mic/session."""
        with self.lock:
            if not self.enabled or self.busy or self.cancel.is_set():return False
            event=self.completion_feedback.take()
            if event is None:return False
            self.busy=True;generation=self.generation;ticket=self.speaker.generation
            self.mic.suspend()
        def work():
            try:
                if self.valid(generation)and not self.cancel.is_set():
                    self.notify('state','speaking')
                    played=self.completion_feedback.play(event,self.speaker,ticket)
                    if not played and self.valid(generation):self.notify('status','Completion is shown on screen; prepared feedback unavailable for this voice.')
            except Exception as error:
                if self.valid(generation):self.notify('error','Completion voice failed: '+type(error).__name__+'. Check the result shown on screen.')
            finally:
                with self.lock:
                    self.busy=False
                    if self.valid(generation)and not self.cancel.is_set():self.mic.resume();self.notify('state','listening')
                self._start_deferred()
        self.feedback_worker=threading.Thread(target=work,daemon=True);self.feedback_worker.start();return True
    def output_event(self,event,ticket,sr):
        with self.lock:
            current=self.turn_metrics
            if event!='first-write' or not current or ticket!=current['ticket'] or not self.valid(current['generation']) or self.cancel.is_set():return
            current['metrics'].setdefault('first_output_write_s',time.monotonic()-current['started'])
    def enable(self,consent=False,cloud_consent=False):
        if not consent:raise ValueError('Microphone needs session consent.')
        with self.lock:
            if self.enabled:return
            if self.busy:raise RuntimeError('Previous voice turn is still stopping. Wait a moment before enabling.')
            self.cloud=bool(cloud_consent);self.enabled=True;self.generation+=1;self.cancel.clear()
            try:self.mic.start(consent=True)
            except Exception:self.enabled=False;raise
    def pause(self):
        # Never wait on the turn worker under its state lock.
        with self.lock:self.enabled=False;self.generation+=1;self.cancel.set();self.pending_utterance=None;self.interrupt_capture=False
        self.mic.close();self.speaker.stop();self.completion_feedback.clear();self.notify('state','off')
    def ask_popup(self,current,asked):
        """One local question between turns. No model request or extra player."""
        with self.lock:
            if not self.enabled or self.busy or self.cancel.is_set():return False
            self.busy=True;self.popup_active=True;generation=self.generation;ticket=self.speaker.generation
            self.mic.suspend()
        def work():
            try:
                if self.valid(generation) and current():
                    self.notify('state','asking Master')
                    self.speaker.speak('Master, shall I read this aloud?',generation=ticket)
                    if self.valid(generation) and self.speaker.generation==ticket and current():asked()
            except Exception as error:self.notify('error','Popup question could not play locally: '+type(error).__name__)
            finally:
                with self.lock:
                    self.busy=False;self.popup_active=False
                    if self.valid(generation) and not self.cancel.is_set():self.mic.resume();self.notify('state','listening')
                self._start_deferred()
        self.popup_worker=threading.Thread(target=work,daemon=True);self.popup_worker.start();return True
    def on_utterance(self,audio):
        with self.lock:
            if not self.enabled:return
            if self.busy:
                if self.interrupt_capture and self.pending_utterance is None:self.pending_utterance=(self.generation,audio)
                return
            self.interrupt_capture=False
            self.busy=True;generation=self.generation;cloud=self.cloud;history=list(self.history)
        threading.Thread(target=self.turn,args=(audio,generation,cloud,history),daemon=True).start()
    def _start_deferred(self):
        with self.lock:
            if self.busy:return
            pending=getattr(self,'pending_utterance',None);self.pending_utterance=None
            if pending and self.enabled and pending[0]==self.generation:self.on_utterance(pending[1])
    def interrupt_and_listen(self):
        """Explicit Ctrl+Alt edge: cancel output, reset echo frames, keep session."""
        with self.lock:
            if not self.enabled or self.cancel.is_set():return False
            generation=self.generation
        self.interrupt(generation)
        with self.lock:
            if not self.enabled:return False
            self.interrupt_capture=True;self.pending_utterance=None
            self.mic.suspend();self.mic.on_onset=None;self.mic.resume()
        return True
    def valid(self,generation):return self.enabled and generation==self.generation
    def turn(self,audio,generation,cloud,history):
        ticket=self.speaker.generation;started=time.monotonic();metrics={};stage='transcription';parallel_dispatched=False;turn_id=uuid.uuid4().hex;route_meta={}
        with self.lock:self.turn_metrics={'ticket':ticket,'started':started,'generation':generation,'metrics':metrics}
        self.notify('metrics',{});self.notify('turn-start',{'turn_id':turn_id,**runtime_device_scope(self.stt,self.speaker)})
        try:
            self.notify('response-diagnostics',[]);self.notify('error','');self.notify('state','transcribing');cancellable=getattr(type(self.stt),'transcribe_cancellable',None);text=cancellable(self.stt,audio,self.cancel)if callable(cancellable)else self.stt.transcribe(audio);metrics['stt_s']=time.monotonic()-started
            with self.lock:
                if not self.valid(generation):return
            # An explicit spoken popup choice uses this already paused mic and
            # installed session speaker, not a second playback or model request.
            popup_handler=getattr(self,'neural_handler',None)
            stage='popup choice validation';popup=popup_handler(text)if callable(popup_handler)else None
            if isinstance(popup,dict):
                with self.lock:
                    if not self.valid(generation):return
                    self.notify('popup-transcript',text);self.notify('action-handled',text)
                if popup.get('text'):
                    self.popup_active=True;stage='popup speech synthesis/playback';self.notify('state','reading popup')
                    self.speaker.speak(popup['text'],generation=ticket)
                return
            with self.lock:
                if not self.valid(generation):return
                self.notify('transcript',text);self.notify('state','thinking')
                # Experimental headphone barge-in: listen for speech onset while
                # generating/speaking. Headphones only; no AEC on speakers.
                if getattr(self,'barge_in',False):
                    self.mic.on_onset=lambda:self.interrupt(generation)
                    self.mic.resume()
            from .wake_address import ambiguous
            from .workspace_voice import VOICES
            if ambiguous(text,VOICES):
                self.notify('error','Recognition contains two adjacent teammate names. I did not choose a persona or run the request. Say Hey Jarvis, Hey Lyra, Hey Dex, or type the intended name.')
                return
            # Browser mode uses only explicit commands, not model decisions or page text.
            handler=getattr(self,'action_handler',None)
            handled=handler(text)if callable(handler)else None
            if isinstance(handled,dict)and isinstance(handled.get('parallel_question'),str):
                parallel_dispatched=True
                metrics['command_dispatch_s']=time.monotonic()-started
                self.notify('status','Browser step dispatched independently; answer is not a browser-result claim')
                text=handled['parallel_question']
            elif handled:
                self.notify('action-handled',text)
                feedback=handled.get('speech_feedback')if isinstance(handled,dict)else None
                if isinstance(feedback,str)and feedback.strip():
                    stage='action feedback playback';self.notify('state','speaking');self.speaker.speak(feedback,generation=ticket)
                return
            from .local_arithmetic import answer as arithmetic_answer
            exact_answer=arithmetic_answer(text)
            if exact_answer is not None:
                with self.lock:
                    if not self.valid(generation)or self.cancel.is_set():return
                    metrics['first_text_s']=time.monotonic()-started
                    self.notify('answer',{'text':exact_answer,'profile':self.persona,'provider':'local-arithmetic','cloud':False,'turn_id':turn_id,'partial':False})
                    self.notify('state','speaking')
                stage='speech synthesis/playback';self.speaker.speak(exact_answer,generation=ticket)
                with self.lock:
                    if not self.valid(generation)or self.cancel.is_set():return
                    if callable(self.record_turn):self.record_turn(text,exact_answer)
                    self.history=(history+[{'role':'user','content':text},{'role':'assistant','content':exact_answer}])[-6:]
                    self.notify('turn-result',{'turn_id':turn_id,'result':'completed','provider':'local-arithmetic','cloud':False,**runtime_device_scope(self.stt,self.speaker)})
                return
            from .persona_text import own_reply
            from .team_discussion import requested,order,clean_reply,messages as discussion_messages
            from .multi_address import addressed,request as addressed_request
            direct=addressed(text)if not requested(text)else()
            if getattr(self,'team_mode',False) and not direct and not requested(text):
                import re
                # Explicit single-name address still reaches only that teammate.
                if not re.match(r'^\s*(?:(?:hey|hi|hello)[,!.:]?\s+)?(?:JARVIS|LYRA|DEX)\b',text,re.I):direct=('JARVIS','LYRA','DEX')
            if direct or requested(text):
                stage='team discussion';context=list((self.shared_context() if callable(self.shared_context) else history)[-12:]);answers=[]
                actors=direct or order(text,self.persona)
                for index,actor in enumerate(actors):
                    if not self.valid(generation)or self.cancel.is_set():return
                    choose=getattr(self.router,'select_persona',None)
                    if callable(choose):choose(actor)
                    select=getattr(self.speaker,'select_profile',None)
                    if callable(select):select(actor)
                    self.persona=actor;self.notify('voice-actor',actor);self.notify('state',actor+' thinking')
                    request=addressed_request(actor,text,context)if direct else discussion_messages(actor,text,context,index)
                    if callable(getattr(self,'interface_context',None)):request[0]['content']+=self.interface_context(text)
                    discussion_router=self.router;discussion_cloud=cloud
                    if self.vision is not None:
                        request=self.vision.attach(request)
                        vision_route=getattr(type(self.vision),'route',None)
                        if callable(vision_route):discussion_router=vision_route(self.vision,discussion_router,request)
                        from .router import image_turn
                        if image_turn(request):discussion_cloud=False
                    if self.streaming:
                        from .speech_queue import SpeechQueue
                        pieces=[];last={};stream_id=str(generation)+'-voice-dialogue-'+str(index)
                        def chunks():
                            nonlocal last
                            for delta in discussion_router.stream(request,cloud_consent=discussion_cloud,cancel=self.cancel):
                                if not self.valid(generation)or self.cancel.is_set():return
                                pieces.append(delta['text']);partial=strip_speaker_tag(''.join(pieces));own_reply(partial,actor,context)
                                if len(partial)>1500:raise ValueError('Team reply too long')
                                last=delta;metrics.setdefault('first_text_s',time.monotonic()-started)
                                route_meta.update(safe_route(delta))
                                self.notify('answer',dict(delta,text=partial,profile=actor,stream_id=stream_id,turn_id=turn_id,partial=True))
                                yield delta['text']
                        def clause(part):
                            metrics.setdefault('first_clause_s',time.monotonic()-started);self.notify('state',actor+' speaking')
                        SpeechQueue(self.speaker,self.cancel,before_output=None).play_stream(spoken_chunks(chunks()),ticket,clause)
                        if not self.valid(generation)or self.cancel.is_set():return
                        answer_text=clean_reply(strip_speaker_tag(''.join(pieces)));own_reply(answer_text,actor,context)
                        self.notify('answer',dict(last,text=answer_text,profile=actor,stream_id=stream_id,turn_id=turn_id,partial=False))
                    else:
                        reply=discussion_router.ask(request,cloud_consent=discussion_cloud,cancel=self.cancel)
                        metrics.setdefault('first_text_s',time.monotonic()-started)
                        answer_text=clean_reply(reply.get('text'));own_reply(answer_text,actor,context)
                        if len(answer_text)>1500:raise ValueError('Team reply too long')
                        if not self.valid(generation)or self.cancel.is_set():return
                        route_meta.update(safe_route(reply));self.notify('answer',dict(reply,text=answer_text,profile=actor,turn_id=turn_id,partial=False));self.notify('state',actor+' speaking');spoken=spoken_text(answer_text)
                        if spoken.strip():self.speaker.speak(spoken,generation=ticket)
                    if not self.valid(generation)or self.cancel.is_set():return
                    context.append({'role':'assistant','content':'['+actor+'] '+answer_text});answers.append(answer_text)
                    if callable(self.record_turn):self.record_turn(text,answer_text)
                self.history=(history+[{'role':'user','content':text}]+context[-6:])[-12:]
                self.notify('turn-result',{'turn_id':turn_id,'result':'completed',**route_meta,**runtime_device_scope(self.stt,self.speaker)})
                return
            # Direct spoken address selects one actual persona and installed voice.
            import re
            from .workspace_voice import VOICES
            names='|'.join(re.escape(n)for n in VOICES)
            match=re.match(r'^\s*(?:(?:hey|hi|hello)[,!.:]?\s+)?('+names+r')\b',text,re.I)
            if not match:match=re.search(r'\b(?:talk|speak|chat)\s+(?:to|with)\s+(jarvis|lyra|dex)\b',text,re.I)
            actor=match.group(1).upper()if match else ('JARVIS'if re.match(r'^\s*(?:(?:hey|hi|hello)[,!.:]?\s+)?laya\b',text,re.I)else self.persona)
            if actor!=self.persona:
                select=getattr(self.speaker,'select_profile',None)
                if callable(select):select(actor);self.persona=actor
            self.notify('voice-actor',self.persona)
            choose=getattr(self.router,'select_persona',None)
            if callable(choose):choose(self.persona)
            if hasattr(self.router,'reasoning_off'):self.router.reasoning_off=self.reasoning_off
            unavailable=vision_unavailable(self.vision,text)
            if unavailable:
                self.notify('answer',{'text':unavailable,'profile':self.persona,'provider':'verified-app-state','turn_id':turn_id,'partial':False});self.notify('state','speaking');self.speaker.speak(unavailable,generation=ticket);return
            stage='local model response'
            context=self.shared_context() if callable(self.shared_context) else history[-6:]
            messages=[{'role':'system','content':prompt(self.persona)+(self.interface_context(text)if callable(getattr(self,'interface_context',None))else'')}]+speaker_context(context,self.persona)+[{'role':'user','content':text}]
            state_local=False
            for source in (getattr(self,'teammate_awareness',None),getattr(self,'agent_nodes',None)):
                if source is not None:
                    messages,attached=source.attach(messages,self.persona);state_local=state_local or attached
            if state_local:cloud=False
            if self.vision is not None:
                stage='local vision frame';messages=self.vision.attach(messages)
            turn_router=self.router
            route=getattr(type(self.vision),'route',None)
            if callable(route):
                turn_router=route(self.vision,turn_router,messages)
                from .router import image_turn
                if image_turn(messages):cloud=False
            stage='local model response'
            if self.streaming:
                from .speech_queue import SpeechQueue
                pieces=[];provider=[]
                def chunks():
                    options={'local_only':True}if state_local else({'configured_chat':True}if getattr(type(turn_router),'supports_configured_chat',False)is True else{})
                    providers=getattr(self.router,'providers',None)
                    if isinstance(providers,list)and len(providers)==1 and not providers[0].cloud and 'spark-x2.5' in providers[0].model.lower():
                        from .lmstudio_rest import NativeSparkTransport,SparkRecoveryTransport
                        options['stream_transport']=NativeSparkTransport() if self.reasoning_off else SparkRecoveryTransport(notify=self.notify)
                    for delta in turn_router.stream(messages,cloud_consent=cloud,cancel=self.cancel,**options):
                        with self.lock:
                            if not self.valid(generation):return
                            if 'first_text_s' not in metrics:metrics['first_text_s']=time.monotonic()-started
                            pieces.append(delta['text']);provider[:]=[delta];route_meta.update(safe_route(delta))
                            own_reply(strip_speaker_tag(''.join(pieces)),self.persona,context)
                            self.notify('answer',{'text':strip_speaker_tag(''.join(pieces)),**{k:delta[k]for k in ('provider','model','cloud','slot')if k in delta},'profile':self.persona,'turn_id':turn_id,'stream_id':turn_id,'partial':True})
                            if delta.get('model'):self.notify('status',delta['provider']+' model '+delta['model'])
                        yield delta['text']
                def guarded_speech():
                    from .streaming import sentences
                    for part in sentences(spoken_chunks(chunks())):
                        if echo_reply(part,text):raise RuntimeError('Model repeated the question instead of answering')
                        yield part+'\n'
                def clause(part):
                    nonlocal stage
                    stage='speech synthesis/playback'
                    with self.lock:
                        if self.valid(generation):
                            if 'first_clause_s' not in metrics:metrics['first_clause_s']=time.monotonic()-started
                            self.notify('state','speaking')
                SpeechQueue(self.speaker,self.cancel,before_output=None).play_stream(guarded_speech(),ticket,clause)
                answer={**(provider[0]if provider else {}),'text':strip_speaker_tag(''.join(pieces))}
                if not answer['text'].strip():raise RuntimeError('Empty reply')
                if echo_reply(answer['text'],text):raise RuntimeError('Model repeated the question instead of answering')
                if self.valid(generation)and not self.cancel.is_set():self.notify('answer',{**answer,'profile':self.persona,'turn_id':turn_id,'stream_id':turn_id,'partial':False})
                warnings=getattr(self.router,'last_warnings',[])
                if isinstance(warnings,list):
                    for warning in warnings:self.notify('error',warning)
                records=getattr(self.router,'last_diagnostics',[])
                if isinstance(records,list):self.notify('response-diagnostics',records)
            else:
                answer=turn_router.ask(messages,cloud_consent=cloud,**({'local_only':True}if state_local else({'configured_chat':True}if getattr(type(turn_router),'supports_configured_chat',False)is True else{})))
                answer['text']=strip_speaker_tag(answer['text'])
                own_reply(answer['text'],self.persona,context)
                if echo_reply(answer['text'],text):raise RuntimeError('Model repeated the question instead of answering')
                with self.lock:
                    if not self.valid(generation):return
                    metrics['first_text_s']=time.monotonic()-started
                    route_meta.update(safe_route(answer));self.notify('answer',{**answer,'turn_id':turn_id,'partial':False});self.notify('state','speaking')
                stage='speech synthesis/playback'
                spoken=spoken_text(answer['text'])
                if spoken.strip():self.speaker.speak(spoken,generation=ticket)
            with self.lock:
                if not self.valid(generation):return
                if callable(self.record_turn):self.record_turn(text,answer['text'])
                self.history=(history+[{'role':'user','content':text},{'role':'assistant','content':answer['text']}])[-6:]
                self.notify('turn-result',{'turn_id':turn_id,'result':'completed',**route_meta,**runtime_device_scope(self.stt,self.speaker)})
        except Exception as exc:
            if self.valid(generation):self.notify('turn-result',{'turn_id':turn_id,**runtime_device_scope(self.stt,self.speaker),'result':'failed','category':'empty-final'if str(exc)=='Empty reply'else'provider-or-runtime-failure','stage':stage,**route_meta})
            records=getattr(self.router,'last_diagnostics',[])
            if stage=='local model response' and isinstance(records,list):self.notify('response-diagnostics',records)
            from .router import RouterError
            from .speech import UnclearSpeech
            detail=str(exc)[:200] if isinstance(exc,RouterError) or (stage=='popup choice validation' and isinstance(exc,ValueError)) else type(exc).__name__
            if 'local-empty-after-retry' in str(exc):detail='local model returned no usable final text after retry (empty streaming and non-streaming replies). This model may not fit this chat template; load a proven chat-instruct model in LM Studio (for example spark-x2.5-4b) or test an enabled cloud account.'
            if 'native-reasoning-off-' in detail:detail+=' Use a non-reasoning model in LM Studio or update LM Studio; no reasoning was spoken'
            with self.lock:
                if self.valid(generation):
                    if isinstance(exc,UnclearSpeech):self.notify('error','Speech was unclear. Please repeat closer to the microphone. Nothing was sent to a model for this turn.')
                    else:self.notify('error','Voice turn failed at '+stage+': '+detail+('. Microphone can listen again; the independent browser step may already be submitted. Check its actual status.'if parallel_dispatched else'. Microphone can listen again; no action was taken.'))
            if self.valid(generation)and not self.cancel.is_set()and (stage.startswith('local vision')or str(exc)=='Model repeated the question instead of answering'):
                feedback='I could not get a usable camera image or vision reply. Vision did not complete; no sight is claimed.'if stage.startswith('local vision')else'The model repeated your question instead of answering. That reply was not accepted.'
                self.notify('answer',{'text':feedback,'profile':self.persona,'provider':'verified-app-state','turn_id':turn_id,'partial':False});self.notify('state','speaking')
                try:self.speaker.speak(feedback,generation=ticket)
                except Exception:self.notify('error','Local failure feedback could not play. '+feedback)
        finally:
            with self.lock:
                self.busy=False;self.popup_active=False
                if self.valid(generation):
                    metrics['turn_s']=time.monotonic()-started;metrics['scope']='session voice processing; first output write is PCM submitted to an adapter, not sound heard; no hardware latency measurement';self.notify('metrics',dict(metrics))
                self.turn_metrics=None;self.mic.on_onset=None
                if self.valid(generation) and not self.cancel.is_set():self.mic.resume();self.notify('state','listening')
                elif self.valid(generation):
                    self.enabled=False;self.mic.stop_event.set();self.speaker.stop();self.notify('state','off - voice failed, press Enable to retry')
            self._start_deferred()
    def interrupt(self,generation):
        """User speech onset during our reply: stop output, keep their new utterance."""
        with self.lock:
            if not self.valid(generation):return
            old=self.cancel;self.cancel=threading.Event();self.generation+=1
            old.set()
        self.speaker.stop();self.notify('state','listening');self.notify('status','Interrupted - listening to you')
    def close(self):
        self.pause();self.history=[];self.shared_context=None;self.record_turn=None
        hook=self.close_hook;self.close_hook=None
        if getattr(self,'fast_ack',None) is not None:self.fast_ack.clear()
        if hook:hook()
