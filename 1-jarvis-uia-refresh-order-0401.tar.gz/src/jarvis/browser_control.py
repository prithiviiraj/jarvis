"""Deterministic local browser voice commands. Page text never becomes instructions.
Navigation uses an isolated automation profile. No send/pay/delete/type automation.
"""
from urllib.parse import urlsplit,urlencode
import ipaddress
class BrowserControl:
 def __init__(self,page):self.page=page
 @staticmethod
 def destination(url):
  if not isinstance(url,str)or len(url)>2048:raise ValueError('Invalid browser destination')
  try:
   p=urlsplit(url);port=p.port
   if p.scheme!='https'or not p.hostname or p.username or p.password or port not in (None,443):raise ValueError()
   host=p.hostname.lower()
   if host in ('localhost','localhost.localdomain')or host.endswith(('.local','.internal','.localhost'))or '.'not in host:raise ValueError()
   try:
    ip=ipaddress.ip_address(host)
    if not ip.is_global:raise ValueError()
   except ValueError:
    if ':'in host or all(x.isdigit()or x=='.'for x in host):raise ValueError()
   return url
  except ValueError:raise ValueError('Use a public HTTPS site, not local or private addresses')
 def execute(self,command,value='',confirmed=False):
  if command=='open-window':
   if confirmed is not True:raise ValueError('Review opening the isolated browser first')
   # Review covers a blank isolated window even when a prior session restored a page.
   self.page.goto('about:blank',wait_until='domcontentloaded',timeout=15000)
   return {'url':self.page.url,'title':self.page.title()[:160]}
  elif command=='search':
   if not isinstance(value,str)or not value.strip()or len(value)>300:raise ValueError('Enter a short search')
   # Search terms leave the machine; review exact text before navigation.
   if confirmed is not True:raise ValueError('Review search terms before opening browser')
   self.page.goto('https://www.google.com/search?'+urlencode({'q':value}),wait_until='domcontentloaded',timeout=15000)
  elif command=='open':
   url=self.destination(value)
   if confirmed is not True:raise ValueError('Review exact destination first')
   self.page.goto(url,wait_until='domcontentloaded',timeout=15000)
  elif command in ('scroll-down','scroll-up','scroll-down-small','scroll-up-small'):
   amount=200 if command.endswith('-small')else 600
   self.page.mouse.wheel(0,amount if command.startswith('scroll-down')else-amount)
  else:raise ValueError('Available: open site, search web, scroll up/down. Sending, buying and form submission are not enabled.')
  return {'url':self.page.url,'title':self.page.title()[:160]}

def parse_voice(text):
 import re
 if not isinstance(text,str):return None
 text=re.sub(r'^\s*(?:(?:hey|hi|hello)\s+)?(?:jarvis|nova|sila|lyra|dex)[, ]*','',text,flags=re.I).strip()
 if text.lower().rstrip('.!') in ('browser open browser','browser open window'):return {'command':'open-window','value':''}
 if text.lower().rstrip('.!')=='browser read links':return {'command':'read-links','value':''}
 match=re.fullmatch(r'browser (?:choose|select) link ([1-9]|1[0-9]|20)[.!]?',text,re.I)
 if match:return {'command':'select-link','value':match.group(1)}
 for phrase,command in [('browser scroll down','scroll-down'),('browser scroll up','scroll-up')]:
  if text.lower().rstrip('.!')==phrase:return {'command':command,'value':''}
 if text.lower().startswith('browser youtube search for '):
  query=text[len('browser youtube search for '):].strip()
  if not query or len(query)>200:raise ValueError('Enter a short YouTube search')
  return {'command':'open','value':'https://www.youtube.com/results?'+urlencode({'search_query':query})}
 for prefix,command in [('browser search for ','search'),('browser open ','open')]:
  if text.lower().startswith(prefix):
   value=text[len(prefix):].strip()
   if command=='open':
    value=value.rstrip(' .!')
    if not value.startswith('https://'):value='https://'+value
    BrowserControl.destination(value)
   elif not value or len(value)>300:raise ValueError('Enter a short browser search')
   return {'command':command,'value':value}
 return None

class BrowserSession:
 """All Playwright operations occur on one worker. Owner's ordinary profile untouched."""
 def __init__(self,root):
  import threading,queue
  self.root=str(root);self.jobs=queue.Queue(maxsize=3);self.lock=threading.RLock();self.state={'state':'off','url':'','requested_url':'','title':'','error':'','links':[]};self.cancel=threading.Event()
  self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
 def snapshot(self):
  with self.lock:return dict(self.state)
 def submit(self,command,value='',confirmed=False,expected_url=None):
  if self.cancel.is_set():raise ValueError('Browser stopping; wait until closed before starting another session')
  if confirmed is not True:raise ValueError('Review browser command first')
  if command=='chain':
   from .browser_chain import validate
   validate(value)
  self.jobs.put_nowait((command,value,expected_url))
  with self.lock:
   self.state['state']='working';self.state['error']=''
   if command in ('open','search','open-window','chain'):self.state.pop('news_text',None);self.state['links']=[]
 def close(self):
  self.cancel.set()
  with self.lock:self.state['state']='stopping'
  return self.thread
 def wait_closed(self,timeout=20):
  """Caller owns bounded shutdown; pending navigation already has a15second cap."""
  import threading
  self.close()
  if self.thread is not threading.current_thread():self.thread.join(timeout)
  if self.thread.is_alive():raise TimeoutError('Isolated browser shutdown did not finish; app is closing without further browser work')
  return True
 def observe_page(self,page):
  # Local browser events only. No reload, fetch, recapture or extra site traffic.
  def navigated(frame):
   if frame!=page.main_frame:return
   with self.lock:
    self.state.update(url=page.url,title='',requested_url='',links=[])
    self.state.pop('news_text',None);self.state['page_revision']=self.state.get('page_revision',0)+1
  def closed():
   with self.lock:self.state.update(state='off',url='',title='',requested_url='',links=[]);self.state.pop('news_text',None)
  page.on('framenavigated',navigated);page.on('close',closed)
 def run(self):
  import queue
  context=None;p=None;page=None;watched=None
  try:
   while not self.cancel.is_set():
    try:command,value,expected_url=self.jobs.get(timeout=.2)
    except queue.Empty:
     if page is not None:
      try:page.wait_for_timeout(200)
      except Exception:
       with self.lock:self.state.update(state='off',url='',links=[]);self.state.pop('news_text',None)
     continue
    try:
     if context is None:
      from playwright.sync_api import sync_playwright
      p=sync_playwright().start()
      from .brave_path import find_brave
      context=p.chromium.launch_persistent_context(self.root,executable_path=find_brave(),headless=False,accept_downloads=False,service_workers='block')
      context.route('**/*',self.route)
     page=context.pages[0]if context.pages else context.new_page()
     if page is not watched:self.observe_page(page);watched=page
     if expected_url is not None:
      if page.url!=expected_url:raise ValueError('Browser page changed; read links again')
      if command=='open':
       from .browser_links import links
       fresh=links(page)
       if value not in {r['url']for r in fresh['links']}:raise ValueError('Selected link changed; read links again')
     if command=='chain':
      from .browser_chain import execute
      with self.lock:self.state['chain_steps']=[]
      def progress(row):
       with self.lock:self.state['chain_steps'].append(row)
      result=execute(page,value,self.cancel,progress)
     elif command=='news-text':
      from .news_page import capture
      captured=capture(page,expected_url);result={'url':page.url,'title':page.title()[:160],'news_text':captured}
     elif command=='read-links':
      from .browser_links import links
      snapshot=links(page);result={'url':page.url,'title':page.title()[:160],'links':snapshot['links']}
     else:
      result=BrowserControl(page).execute(command,value,confirmed=True)
      result['links']=[]
      if command=='open':result['requested_url']=value
      elif command=='search':result['requested_url']='https://www.google.com/search?'+urlencode({'q':value})
     with self.lock:self.state.update(state='ready',error='',**result)
    except Exception as error:
     category=type(error).__name__
     detail=str(error).lower()
     if 'brave not found' in detail:reason='Brave not found in standard install locations. Install Brave first; no Edge fallback.'
     elif 'executable' in detail or 'browser distribution' in detail:reason='Installed Brave executable was not found.'
     elif 'timeout' in detail:reason='Browser startup or navigation timed out.'
     elif isinstance(error,ValueError):reason='Reviewed command or current page no longer matches.'
     else:reason='Browser startup or navigation failed ('+category+').'
     with self.lock:self.state.update(state='error',error=reason+' Earlier completed chain steps, if listed, remain completed; remaining steps did not run. Check Settings > Tools. Your ordinary browser is unchanged.')
  finally:
   if context:
    try:context.close()
    except Exception:pass
   if p:p.stop()
   with self.lock:self.state['state']='off'
 @staticmethod
 def route(route):
  # No non-read requests. Check every network destination incl redirects/resources.
  try:
   BrowserControl.destination(route.request.url)
   import socket
   host=urlsplit(route.request.url).hostname
   addresses=socket.getaddrinfo(host,443,type=socket.SOCK_STREAM)
   if not addresses or any(not ipaddress.ip_address(x[4][0]).is_global for x in addresses):raise ValueError()
   if route.request.method not in ('GET','HEAD'):raise ValueError()
   route.continue_()
  except (ValueError,OSError):route.abort()
