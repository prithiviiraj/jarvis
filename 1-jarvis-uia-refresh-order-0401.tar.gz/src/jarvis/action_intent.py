"""Bounded explicit browser intents for any persona. Questions do not become effects."""
import re
from .browser_control import parse_voice

def normalize(text):
 # Whisper/typing may spell the leader as J.A.R.V.I.S.; only normalize the name.
 text=re.sub(r'\bj\s*\.\s*a\s*\.\s*r\s*\.\s*v\s*\.\s*i\s*\.\s*s\s*\.?', 'Jarvis',text,flags=re.I)
 # Only normalize dots between a bounded imperative's known words. Do not rewrite URLs.
 return re.sub(r'\b(open|the|a)\.\s+(?=(?:the[.\s]|a[.\s]|browser\b|youtube\b))',r'\1 ',text,flags=re.I)

def parse(text):
 if not isinstance(text,str):return None
 text=normalize(text)
 # Groq/Whisper may return Tamil script rather than Roman Tanglish. Exact
 # bounded imperatives only; negation and general sentences are never stripped.
 tamil=re.sub(r'^\s*(?:(?:ஜார்விஸ்|டெக்ஸ்|லைரா|jarvis|dex|lyra)[,.:!]?\s+)?','',text,flags=re.I).strip().rstrip('.!?')
 if re.fullmatch(r'(?:பிரவுசர்|பிரவுசரை|பிரவுசரைத்|browser) (?:ஓபன் பண்ணு|திற|திறந்து வை)',tamil,re.I):return {'command':'open-window','value':''}
 if re.fullmatch(r'(?:யூடியூப்|யூடியூபை|YouTube) (?:ஓபன் பண்ணு|திற|திறந்து வை)',tamil,re.I):return {'command':'open','value':'https://www.youtube.com/'}
 if re.fullmatch(r'(?:கீழே|கீழ|down) (?:ஸ்க்ரோல்|scroll)(?: பண்ணு)?|(?:ஸ்க்ரோல்|scroll) (?:கீழே|டவுன்)(?: பண்ணு)?',tamil,re.I):return {'command':'scroll-down','value':''}
 if re.fullmatch(r'(?:மேலே|மேல|up) (?:ஸ்க்ரோல்|scroll)(?: பண்ணு)?|(?:ஸ்க்ரோல்|scroll) (?:மேலே|அப்)(?: பண்ணு)?',tamil,re.I):return {'command':'scroll-up','value':''}
 t=re.sub(r'^\s*(?:(?:hey|hi|hello)[,!]?\s+)?(?:(?:jarvis|nova|sila|lyra|dex|laya|reo)(?:[.,:!]\s*|\s+))?','',text,flags=re.I).strip()
 # Exact Tanglish commands only; no substring stripping or negation removal.
 if re.fullmatch(r'(?:brave(?: browser)?|browser) (?:open pannu|thirandhu|thira)',t,re.I):return {'command':'open-window','value':''}
 if re.fullmatch(r'scroll (?:down|keela)(?: pannu)?',t,re.I):return {'command':'scroll-down','value':''}
 if re.fullmatch(r'scroll (?:up|mela)(?: pannu)?',t,re.I):return {'command':'scroll-up','value':''}
 t=re.sub(r'^(?:(?:can|could|would)\s+you\s+|please\s+)','',t,flags=re.I)
 t=t.strip().rstrip('.!?')
 # Only bounded launch verbs, never remove question/negation clauses.
 t=re.sub(r'^(?:launch|start|bring up)\s+(?=(?:this |the |a )?(?:browser|brave)(?: browser)?(?:$|\s+(?:for me|now|please)$))','open ',t,flags=re.I)
 # Bounded politeness only; do not remove arbitrary suffixes or URL text.
 if re.fullmatch(r'open (?:this |the |a )?browser(?: (?:for me|now|please)){1,2}',t,re.I):t=re.sub(r'(?: (?:for me|now|please)){1,2}$','',t,flags=re.I)
 t=re.sub(r'\s+please$','',t,flags=re.I).strip()
 if re.fullmatch(r'(?:open (?:this |the |a )?browser and )?open (?:the )?youtube',t,re.I):return {'command':'open','value':'https://www.youtube.com/'}
 if re.fullmatch(r'open (?:this |the |a )?(?:browser|brave|brave browser)',t,re.I):return {'command':'open-window','value':''}
 m=re.fullmatch(r'scroll\s+(?:(slightly|a little)\s*)?(up|down)?(?:\s+(slightly|a little))?',t,re.I)
 if m:
  return {'command':'scroll-'+(m.group(2)or'down')+('-small'if m.group(1)or m.group(3)else''),'value':''}
 if re.match(r'^(?:what|when|why|how|is|are|do|does)\b',t,re.I):return None
 if t.lower().startswith(('open https://','open http://','open www.')):return parse_voice('browser '+t)
 if t.lower().startswith('browser '):
  proposal=parse_voice(t)
  return proposal if proposal and proposal['command']in ('open','search','scroll-down','scroll-up','open-window')else None
 return None

def goal(text):
 if not isinstance(text,str):return None
 text=normalize(text)
 from .reo_commands import parse as reo_parse
 normalized=re.sub(r'^\s*(?:(?:hey|hi|hello)[,!]?\s+)?(?:(?:jarvis|nova|sila|lyra|dex|laya|reo)(?:[.,:!]\s*|\s+))?','',text,flags=re.I).strip()
 normalized=re.sub(r'^(?:(?:can|could|would)\s+you\s+|please\s+)','',normalized,flags=re.I)
 if re.match(r'^(?:what|when|why|how|is|are|do|does)\b',normalized,re.I):return None
 if normalized.lower()in ('browser read links',)or re.fullmatch(r'browser (?:choose|select) link \d+[.!]?',normalized,re.I):return None
 return reo_parse('Reo '+normalized)
