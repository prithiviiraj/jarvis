"""Plug into an existing bridge. Never poll Telegram or handle credentials here."""
import io
import time
from core import Client, LocalError, prepare_image

class Adapter:
    def __init__(self, bridge_module, client=None, preview=None):
        self.module = bridge_module
        self.client = client or Client()
        self.preview = preview or review_image

    def handle(self, bridge, message):
        if not self.module.is_owner(message, bridge.owner):
            return True  # Never pass an untrusted sender to any AI handler.
        text = message.get('text', '').strip()
        command = text.split(maxsplit=1)[0] if text else ''
        if command not in ('/ai', '/see', '/aiclear'):
            return False
        if not 0 <= time.time() - message.get('date', 0) <= self.module.MAX_AGE:
            return True
        if command == '/aiclear':
            self.client.clear()
            print('JARVIS session cleared locally.')
            return True
        question = text[len(command):].strip()
        if not question or len(question) > 6000:
            print('Use /ai <question> or /see <screen question>, maximum 6000 characters.')
            return True
        # Permission at the laptop, not text injected remotely.
        if not self.module.approve('Ask LOCAL JARVIS this question?\n' + question):
            return True
        image = None
        if command == '/see':
            if not self.module.approve('Capture once for LOCAL analysis? Close private windows first. Screenshots are not sent to Telegram.'):
                return True
            image = prepare_image(self.module.capture_screen())
            if not self.preview(image):
                return True
        try:
            answer, elapsed = self.client.ask(question, image)
        except LocalError as exc:
            print('JARVIS:', str(exc))
            return True
        outgoing = 'JARVIS: ' + answer
        print('Local response (%.1fs):\n%s' % (elapsed, outgoing))
        # Review generated words and recipient together before disclosure to Telegram.
        if self.module.approve('Send this exact answer to your paired private Telegram chat?\n' + outgoing):
            bridge.send(outgoing)
        return True

def review_image(raw):
    import tkinter as tk
    from PIL import Image, ImageTk
    root = tk.Tk()
    root.title('JARVIS: review local screenshot')
    image = Image.open(io.BytesIO(raw))
    image.thumbnail((800,500))
    photo = ImageTk.PhotoImage(image)
    tk.Label(root,image=photo).pack(padx=12,pady=12)
    tk.Label(root,text='Use this image ONLY in local LM Studio? No image goes to Telegram.').pack(padx=12)
    decision = [False]
    def yes():
        decision[0] = True
        root.destroy()
    tk.Button(root,text='Use locally',command=yes).pack(side='left',padx=16,pady=12)
    tk.Button(root,text='Cancel',command=root.destroy).pack(side='right',padx=16,pady=12)
    root.mainloop()
    return decision[0]
