from core import Client, LocalError

def main():
    client = Client()
    print('JARVIS local chat. /quit stops, /clear clears the session. Screen preview is in the desktop app.')
    while True:
        text = input('You: ').strip()
        if text == '/quit':
            return
        if text == '/clear':
            client.clear()
            continue
        try:
            answer, elapsed = client.ask(text)
            print('JARVIS (%.1fs): %s' % (elapsed, answer))
        except LocalError as exc:
            print(str(exc))

if __name__ == '__main__':
    try:
        main()
    except (EOFError, KeyboardInterrupt):
        print('\nStopped.')
