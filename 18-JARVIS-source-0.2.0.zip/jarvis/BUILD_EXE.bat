@echo off
cd /d "%~dp0"
echo JARVIS - build Windows EXE. This can take several minutes.
if not exist .venv\Scripts\python.exe (
 py -3.12 -m venv .venv
 if errorlevel 1 goto failed
)
.venv\Scripts\python.exe -m pip install -r requirements.txt "pyinstaller>=6.10,<7"
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onedir --windowed --name JARVIS --collect-all PIL --collect-all customtkinter --collect-data cv2 app.py
if errorlevel 1 goto failed
copy /y config.example.json dist\JARVIS\config.json >nul
copy /y notes.example.txt dist\JARVIS\notes.txt >nul
copy /y README.md dist\JARVIS\README.md >nul
echo Built: dist\JARVIS\JARVIS.exe. Start LM Studio first, then double-click JARVIS.exe.
echo This app is unsigned. If Windows blocks it, do not bypass security warnings blindly.
explorer dist
pause
exit /b 0
:failed
echo Build stopped. Send the error text WITHOUT secrets. Do not disable SSL checks.
pause
exit /b 1
