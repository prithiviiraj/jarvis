@echo off
cd /d "%~dp0"
echo JARVIS - setup. Python 3.12 must already be installed.
py -3.12 -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe -c "import tkinter; from PIL import Image; print('JARVIS dependencies ready.')"
if errorlevel 1 goto failed
echo Setup complete. Start LM Studio, then double-click RUN.bat.
pause
exit /b 0
:failed
echo Setup stopped. Do not disable SSL checks. Send the error text WITHOUT secrets.
pause
exit /b 1
