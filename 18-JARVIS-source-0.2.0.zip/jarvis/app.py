"""JARVIS desktop. All monitoring starts OFF and requires session consent."""
import io
import os
import queue
import threading
import time
import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
from core import Client, LocalError, screenshot
from monitor import ScreenSchedule, CameraMonitor, SCREEN_PROMPT

ctk.set_appearance_mode('dark')
ctk.set_default_color_theme('dark-blue')
BG='#0d0f14'; PANEL='#151922'; MUTED='#8991a5'; ACCENT='#a6ffcf'

class App:
    def __init__(self,root):
        self.root=root
        self.client=Client()
        self.events=queue.Queue()
        self.schedule=ScreenSchedule()
        self.camera=CameraMonitor(self.events)
        self.camera_on=False
        self.busy=False
        self.closed=False
        self.session_start=time.monotonic()
        self.last_presence=None
        self.next_break=float("inf")
        self.toast=None
        root.title(self.client.config.get('project_name','JARVIS'))
        root.geometry('1140x760'); root.minsize(940,660)
        root.configure(fg_color=BG)
        root.grid_columnconfigure(1,weight=1); root.grid_rowconfigure(0,weight=1)
        self.sidebar=ctk.CTkFrame(root,width=200,fg_color='#11141b',corner_radius=0)
        self.sidebar.grid(row=0,column=0,sticky='nsew'); self.sidebar.grid_propagate(False)
        ctk.CTkLabel(self.sidebar,text='J A R V I S',font=('Segoe UI',26,'bold'),text_color=ACCENT).pack(anchor='w',padx=24,pady=(30,2))
        ctk.CTkLabel(self.sidebar,text='Your local companion',text_color=MUTED).pack(anchor='w',padx=24)
        ctk.CTkLabel(self.sidebar,text='WORKSPACE',text_color=MUTED,font=('Segoe UI',11,'bold')).pack(anchor='w',padx=24,pady=(38,12))
        ctk.CTkButton(self.sidebar,text='Conversation',fg_color='#253d36',text_color=ACCENT,anchor='w',height=42,command=lambda:self.input.focus_set()).pack(fill='x',padx=18)
        for label,action in (('Screen context',lambda:self.ask(True)),('Mentor activity',lambda:self.feed.focus_set()),('Local privacy',self.privacy)):
            ctk.CTkButton(self.sidebar,text=label,command=action,fg_color='transparent',text_color='#b9c0cf',anchor='w',height=40,hover_color='#242a38').pack(fill='x',padx=18)
        ctk.CTkLabel(self.sidebar,text='No cloud fallback\nNo auto-start\nNo saved frames',text_color=MUTED,justify='left').pack(side='bottom',anchor='w',padx=24,pady=26)
        main=ctk.CTkFrame(root,fg_color=BG,corner_radius=0)
        main.grid(row=0,column=1,sticky='nsew',padx=24,pady=20)
        main.grid_columnconfigure(0,weight=1); main.grid_rowconfigure(2,weight=1)
        header=ctk.CTkFrame(main,fg_color='transparent')
        header.grid(row=0,column=0,sticky='ew',pady=(0,18)); header.grid_columnconfigure(0,weight=1)
        ctk.CTkLabel(header,text='A little focus. A useful next step.',font=('Segoe UI',24,'bold')).grid(row=0,column=0,sticky='w')
        ctk.CTkLabel(header,text='Local model, visible controls, your pace.',text_color=MUTED).grid(row=1,column=0,sticky='w')
        self.link=ctk.CTkButton(header,text='Check LM Studio',width=135,fg_color='#242a38',command=self.check_server)
        self.link.grid(row=0,column=1,rowspan=2,padx=(10,0))
        controls=ctk.CTkFrame(main,fg_color=PANEL,corner_radius=14)
        controls.grid(row=1,column=0,sticky='ew',pady=(0,16)); controls.grid_columnconfigure(2,weight=1)
        self.screen_var=tk.BooleanVar(value=False); self.camera_var=tk.BooleanVar(value=False)
        self.screen_toggle=ctk.CTkSwitch(controls,text='Screen agent',variable=self.screen_var,command=self.toggle_screen,progress_color='#3a8c68')
        self.screen_toggle.grid(row=0,column=0,sticky='w',padx=18,pady=(18,8))
        self.camera_toggle=ctk.CTkSwitch(controls,text='Camera presence',variable=self.camera_var,command=self.toggle_camera,progress_color='#3a8c68')
        self.camera_toggle.grid(row=0,column=1,sticky='w',padx=18,pady=(18,8))
        self.stop=ctk.CTkButton(controls,text='Pause all',width=94,fg_color='#33394a',command=self.pause_all)
        self.stop.grid(row=0,column=2,sticky='e',padx=18,pady=(18,8))
        self.sensor_status=ctk.CTkLabel(controls,text='MONITORING OFF  /  Screen checks every 120s when enabled',text_color=MUTED,anchor='w')
        self.sensor_status.grid(row=1,column=0,columnspan=3,sticky='ew',padx=18,pady=(0,16))
        workspace=ctk.CTkFrame(main,fg_color='transparent')
        workspace.grid(row=2,column=0,sticky='nsew'); workspace.grid_columnconfigure(0,weight=3);workspace.grid_columnconfigure(1,weight=2);workspace.grid_rowconfigure(0,weight=1)
        chat_panel=ctk.CTkFrame(workspace,fg_color=PANEL,corner_radius=14)
        chat_panel.grid(row=0,column=0,sticky='nsew',padx=(0,14)); chat_panel.grid_rowconfigure(1,weight=1);chat_panel.grid_columnconfigure(0,weight=1)
        title=ctk.CTkFrame(chat_panel,fg_color='transparent');title.grid(row=0,column=0,sticky='ew',padx=16,pady=12)
        ctk.CTkLabel(title,text='Conversation',font=('Segoe UI',16,'bold')).pack(side='left')
        self.reset=ctk.CTkButton(title,text='Clear',width=55,fg_color='#242a38',command=self.clear);self.reset.pack(side='right')
        self.chat=ctk.CTkTextbox(chat_panel,fg_color=PANEL,wrap='word',font=('Segoe UI',14),height=140)
        self.chat.grid(row=1,column=0,sticky='nsew',padx=12,pady=(0,12)); self.chat.configure(state='disabled')
        self.write('JARVIS\nVanakkam bro. What do you want to finish today? I can help with Maya practice and small next steps.\n')
        right=ctk.CTkFrame(workspace,fg_color=PANEL,corner_radius=14);right.grid(row=0,column=1,sticky='nsew');right.grid_columnconfigure(0,weight=1);right.grid_rowconfigure(3,weight=1)
        ctk.CTkLabel(right,text='Agent activity',font=('Segoe UI',16,'bold')).grid(row=0,column=0,sticky='w',padx=18,pady=(16,8))
        self.presence=ctk.CTkLabel(right,text='Camera off',text_color=MUTED,anchor='w');self.presence.grid(row=1,column=0,sticky='ew',padx=18)
        ctk.CTkLabel(right,text='Ephemeral checks. No recordings.',text_color=MUTED,font=('Segoe UI',11)).grid(row=2,column=0,sticky='w',padx=18,pady=(4,12))
        self.feed=ctk.CTkTextbox(right,fg_color=PANEL,wrap='word',font=('Segoe UI',12),height=140)
        self.feed.grid(row=3,column=0,sticky='nsew',padx=12,pady=(0,12));self.feed.configure(state='disabled')
        self.activity('Ready. Screen and camera are OFF. Enable only when your desktop is safe to view.')
        composer=ctk.CTkFrame(main,fg_color=PANEL,corner_radius=14);composer.grid(row=3,column=0,sticky='ew',pady=(16,0));composer.grid_columnconfigure(0,weight=1)
        self.input=ctk.CTkTextbox(composer,height=65,fg_color=PANEL,wrap='word',font=('Segoe UI',14));self.input.grid(row=0,column=0,columnspan=2,sticky='ew',padx=14,pady=(8,0))
        self.screen=ctk.CTkButton(composer,text='Add screen context',fg_color='#242a38',command=lambda:self.ask(True));self.screen.grid(row=1,column=0,sticky='w',padx=14,pady=12)
        self.send=ctk.CTkButton(composer,text='Ask JARVIS',fg_color=ACCENT,text_color='#0d2118',hover_color='#77cc9f',command=lambda:self.ask(False));self.send.grid(row=1,column=1,sticky='e',padx=14,pady=12)
        self.status=tk.StringVar(value='Ready. Start LM Studio to connect your local brain.')
        ctk.CTkLabel(main,textvariable=self.status,text_color=MUTED,anchor='w',wraplength=820).grid(row=4,column=0,sticky='ew',pady=(10,0))
        root.protocol('WM_DELETE_WINDOW',self.close)
        root.after(100,self.poll)

    def privacy(self):
        messagebox.showinfo('Local privacy','Screen: one primary-monitor frame every 120s only after session consent and while minimized. Camera: local face presence every 2s, never identity or health. No frames saved. Activity/chat only in memory. Pause all cancels future checks, but an in-flight local inference may finish before its answer is discarded. Do not monitor a shared or private desktop. Telegram is separate and not offline.')
    def nudge(self,text):
        self.activity(text)
        if self.root.state() != 'iconic':return
        if self.toast and self.toast.winfo_exists():self.toast.destroy()
        self.toast=ctk.CTkToplevel(self.root)
        toast=self.toast
        toast.title('JARVIS nudge');toast.geometry('380x210');toast.attributes('-topmost',True)
        ctk.CTkLabel(toast,text='JARVIS / LOCAL NUDGE',text_color=ACCENT,font=('Segoe UI',15,'bold')).pack(anchor='w',padx=20,pady=(16,6))
        ctk.CTkLabel(toast,text=text,wraplength=335,justify='left').pack(fill='both',expand=True,padx=20)
        ctk.CTkButton(toast,text='Pause all',command=lambda:(self.pause_all(),toast.destroy())).pack(side='left',padx=20,pady=14)
        ctk.CTkButton(toast,text='Dismiss',fg_color='#33394a',width=85,command=toast.destroy).pack(side='right',padx=20,pady=14)
        toast.after(20000,lambda:toast.destroy() if toast.winfo_exists() else None)
    def write(self,text):
        self.chat.configure(state='normal');self.chat.insert('end',text+'\n');self.chat.see('end');self.chat.configure(state='disabled')
    def activity(self,text):
        self.feed.configure(state='normal');self.feed.insert('end',time.strftime('%H:%M')+'  '+text+'\n\n');self.feed.see('end');self.feed.configure(state='disabled')
        # Session activity only, bounded and never written to disk.
        if len(self.feed.get('1.0','end'))>12000:
            self.feed.configure(state='normal');self.feed.delete('1.0','15.0');self.feed.configure(state='disabled')
    def set_busy(self,value):
        self.busy=value
        for w in (self.send,self.screen,self.link,self.reset):w.configure(state='disabled' if value else 'normal')
    def worker(self,fn,kind='answer',generation=None):
        self.set_busy(True);self.status.set('Thinking locally... monitoring never runs a second inference in parallel.')
        def run():
            try:self.events.put((kind,generation,fn()))
            except Exception as exc:self.events.put(('error',generation,str(exc) if isinstance(exc,LocalError) else 'Local operation failed. Check model or device and retry manually.'))
        threading.Thread(target=run,daemon=True).start()
    def poll(self):
        if self.closed:return
        while True:
            try:kind,generation,result=self.events.get_nowait()
            except queue.Empty:break
            if kind.startswith('camera'):
                if generation!=self.camera.serial:continue
                if kind=='camera':
                    self.presence.configure(text='Face detected (not identity)' if result else 'No face detected (not proof of absence)',text_color=ACCENT if result else MUTED)
                    if result and self.last_presence is False:self.nudge('Welcome back. Ready for one small step?')
                    self.last_presence=result
                elif kind=='camera_error':
                    self.camera_on=False;self.camera_var.set(False);self.presence.configure(text=result,text_color='#ff9a9a');self.activity(result)
                elif kind=='camera_stopped':self.camera_on=False
                self.sensor_label();continue
            self.set_busy(False)
            if kind=='error':
                self.status.set(result)
                if generation is not None:
                    if self.schedule.valid(generation):self.pause_screen();self.activity('Screen agent paused after an error. No automatic inference retry.')
                else:self.write('JARVIS\n'+result)
            elif kind=='nudge':
                answer,seconds=result
                if self.schedule.valid(generation):
                    self.status.set('Screen check finished in %.1fs. Frame discarded.'%seconds)
                    if answer.strip()!='NO_NUDGE' and self.schedule.accept_nudge(generation):self.nudge(answer[:600])
            else:
                answer,seconds=result;self.write('JARVIS\n'+answer+'\n');self.status.set('Finished in %.1fs. No screenshot stored.'%seconds)
        if (self.schedule.enabled or self.camera_on) and time.monotonic() >= self.next_break:
            self.next_break=time.monotonic()+2700
            self.nudge('A gentle break check: if comfortable, look away from the screen and stretch. This is a timer, not a health assessment.')
        # Do not capture the assistant itself. Only watch while minimized.
        if self.schedule.due(self.busy):
            if self.root.state()=='iconic' and not (self.toast and self.toast.winfo_exists()):self.monitor_screen()
            else:self.schedule.begin();self.activity('Screen check skipped while JARVIS is open. Minimize to observe your workspace; monitoring remains visibly enabled.')
        self.root.after(200,self.poll)
    def sensor_label(self):
        text='SCREEN ON (120s)' if self.schedule.enabled else 'SCREEN OFF'
        text+='  /  CAMERA ON (2s CPU checks)' if self.camera_on else '  /  CAMERA OFF'
        self.sensor_status.configure(text=text,text_color=ACCENT if self.schedule.enabled or self.camera_on else MUTED)
    def toggle_screen(self):
        if not self.screen_var.get():self.pause_screen();return
        consent=messagebox.askokcancel('Enable visible screen agent?',
            'While JARVIS is minimized, capture the primary screen once every 120 seconds and analyze it in LOCAL LM Studio. Nudges have a 10-minute cooldown. No frames are saved.\n\nAnything visible may be captured, including private content. Close private windows, pause before passwords/payment/messages, and do not enable on a shared desktop. Pause all or close JARVIS to stop. Monitoring starts OFF on every launch. Enable this session?')
        if not consent:self.screen_var.set(False);return
        self.schedule.start();self.next_break=time.monotonic()+2700;self.sensor_label();self.activity('Screen agent enabled for this session. First check in 120s after minimizing. Pause before private work.')
    def pause_screen(self):
        self.schedule.stop();self.screen_var.set(False);self.sensor_label()
    def toggle_camera(self):
        if not self.camera_var.get():self.camera.stop();self.camera_on=False;self.presence.configure(text='Camera stopping / releasing device');self.sensor_label();return
        if not messagebox.askokcancel('Enable local camera presence?',
            'Use camera 0 for local face-presence checks every 2 seconds. No video or frames saved or sent to LM Studio/Telegram. This does NOT recognize identity, emotions, health or prove absence. Lighting and angles cause errors. Enable only with consent of anyone in view. Camera light may stay on while enabled. Stop with Pause all or closing JARVIS. Enable this session?'):
            self.camera_var.set(False);return
        if not self.camera.start():
            self.camera_var.set(False);self.activity('Previous camera session is still releasing. Try again in a moment.');return
        self.camera_on=True;self.next_break=time.monotonic()+2700;self.sensor_label();self.presence.configure(text='Camera starting...');self.activity('Camera presence enabled locally. No recordings.')
    def pause_all(self):
        self.pause_screen();self.camera.stop();self.camera_on=False;self.camera_var.set(False);self.presence.configure(text='Camera stopping / releasing device');self.sensor_label();self.activity('All monitoring paused. In-flight inference may finish locally; its nudge will be discarded.')
    def monitor_screen(self):
        generation=self.schedule.begin()
        def analyze():
            if not self.schedule.valid(generation):return ('NO_NUDGE',0)
            image=screenshot()
            if not self.schedule.valid(generation):return ('NO_NUDGE',0)
            return self.client.ask(SCREEN_PROMPT,image,remember=False)
        self.worker(analyze,'nudge',generation)
    def ask(self,use_screen):
        if self.busy:return
        text=self.input.get('1.0','end').strip()
        if not text:messagebox.showinfo('Question needed','Type a question first, bro.');return
        if use_screen:
            if not messagebox.askokcancel('Close private screens','Capture the primary monitor once for LOCAL LM Studio? Close private windows first. You will review the image next.'):return
            self.root.withdraw();self.root.after(400,lambda:self.capture_preview(text))
        else:self.submit(text,None)
    def capture_preview(self,text):
        try:image=screenshot()
        except Exception:
            self.root.deiconify();messagebox.showerror('Capture failed','An unlocked interactive desktop and screen permission are required.');return
        self.root.deiconify()
        from PIL import Image,ImageTk
        dialog=ctk.CTkToplevel(self.root);dialog.title('Review screen context');dialog.after(100,dialog.grab_set)
        pic=Image.open(io.BytesIO(image));pic.thumbnail((780,460));photo=ImageTk.PhotoImage(pic)
        label=tk.Label(dialog,image=photo,bg=BG);label.image=photo;label.pack(padx=16,pady=16)
        ctk.CTkLabel(dialog,text='This image goes only to your local model. No image saved.').pack(padx=16)
        def confirm():dialog.destroy();self.submit(text,image)
        ctk.CTkButton(dialog,text='Use locally',command=confirm).pack(side='left',padx=16,pady=16)
        ctk.CTkButton(dialog,text='Cancel',fg_color='#33394a',command=dialog.destroy).pack(side='right',padx=16,pady=16)
    def submit(self,text,image):
        self.write('YOU\n'+text+('  [local screen context]' if image else '')+'\n');self.input.delete('1.0','end');self.worker(lambda:self.client.ask(text,image))
    def check_server(self):self.worker(lambda:('Available local models: '+', '.join(self.client.models()),0))
    def clear(self):
        self.client.clear();self.chat.configure(state='normal');self.chat.delete('1.0','end');self.chat.configure(state='disabled');self.status.set('Session cleared. No chat log saved.')
    def close(self):
        self.closed=True;self.schedule.stop();self.camera.stop();self.root.destroy()

if __name__=='__main__':
    root=ctk.CTk()
    try:App(root)
    except Exception as exc:messagebox.showerror('Startup stopped',str(exc));root.destroy()
    else:
        if os.environ.get('JARVIS_SMOKE_TEST')=='1':
            def smoke():
                from PIL import ImageGrab
                root.update();ImageGrab.grab().save(os.environ['JARVIS_SMOKE_OUTPUT']);root.destroy()
            root.after(1500,smoke)
        root.mainloop()
