import importlib.util
import os
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from bridge_adapter import Adapter

class TestActualBridge(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path=os.environ.get('BRIDGE_TEST_SOURCE')
        if not path: raise unittest.SkipTest('Actual bridge source not supplied. Set BRIDGE_TEST_SOURCE locally.')
        spec=importlib.util.spec_from_file_location('tested_bridge',path)
        cls.module=importlib.util.module_from_spec(spec); spec.loader.exec_module(cls.module)
    def setUp(self):
        self.bridge=self.module.Bridge('not-a-token',self.module.OWNER_ID,Path('/tmp'))
        self.bridge.send=Mock()
        self.client=Mock(); self.client.ask.return_value=('Draft answer',0.1)
        self.adapter=Adapter(self.module,self.client,preview=Mock(return_value=True))
        self.old_approve=self.module.approve
        self.module.approve=Mock(return_value=True)
        self.msg={'from':{'id':self.module.OWNER_ID},'chat':{'id':self.module.OWNER_ID,'type':'private'},'date':int(time.time()),'text':'/ai Hello'}
    def tearDown(self): self.module.approve=self.old_approve
    def test_owner_question_and_review(self):
        self.assertTrue(self.adapter.handle(self.bridge,self.msg))
        self.client.ask.assert_called_once_with('Hello',None)
        self.assertEqual(self.module.approve.call_count,2)
        self.bridge.send.assert_called_once_with('JARVIS: Draft answer')
    def test_reject_foreign_sender(self):
        self.msg['from']['id']=123
        self.adapter.handle(self.bridge,self.msg)
        self.client.ask.assert_not_called(); self.bridge.send.assert_not_called()
    def test_reject_group(self):
        self.msg['chat']['type']='group'
        self.adapter.handle(self.bridge,self.msg); self.client.ask.assert_not_called()
    def test_reject_forward(self):
        self.msg['forward_origin']={'type':'user'}
        self.adapter.handle(self.bridge,self.msg); self.client.ask.assert_not_called()
    def test_reject_stale(self):
        self.msg['date']-=200
        self.adapter.handle(self.bridge,self.msg); self.client.ask.assert_not_called()
    def test_no_send_without_review(self):
        self.module.approve.side_effect=[True,False]
        self.adapter.handle(self.bridge,self.msg); self.bridge.send.assert_not_called()
    def test_no_inference_after_denial(self):
        self.module.approve.return_value=False
        self.adapter.handle(self.bridge,self.msg); self.client.ask.assert_not_called()
    def test_original_commands_fall_through(self):
        self.msg['text']='/status'
        self.assertFalse(self.adapter.handle(self.bridge,self.msg)); self.client.ask.assert_not_called()
    def test_ipv6_patch_preserved(self):
        self.assertTrue(hasattr(self.module,'_ORIGINAL_GETADDRINFO'))
        self.assertTrue(callable(self.module.telegram_getaddrinfo))

if __name__ == '__main__': unittest.main()
