"""Build-runner UI smoke: no network or screen capture."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import tkinter as tk
from app import App
root = __import__("customtkinter").CTk()
app = App(root)
root.update()
assert root.title() == 'JARVIS'
assert app.chat.winfo_width() > 300
assert app.send.winfo_ismapped()
root.after(400,root.destroy)
root.mainloop()
print('Tk window smoke passed.')
