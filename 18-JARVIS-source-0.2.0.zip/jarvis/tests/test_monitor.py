import unittest
from monitor import ScreenSchedule
class TestSchedule(unittest.TestCase):
    def setUp(self):
        self.now=1000
        self.s=ScreenSchedule(clock=lambda:self.now)
    def test_off_by_default(self):self.assertFalse(self.s.due())
    def test_consent_start_wait(self):
        self.s.start();self.assertFalse(self.s.due());self.now+=120;self.assertTrue(self.s.due())
    def test_serial_work(self):
        self.s.start();self.now+=120;self.assertFalse(self.s.due(busy=True))
    def test_pause_discards_inflight(self):
        self.s.start();g=self.s.begin();self.s.stop();self.assertFalse(self.s.valid(g));self.assertFalse(self.s.accept_nudge(g))
    def test_new_session_discards_old(self):
        g=self.s.start();self.s.stop();self.s.start();self.assertFalse(self.s.valid(g))
    def test_cooldown(self):
        g=self.s.start();self.assertTrue(self.s.accept_nudge(g));self.assertFalse(self.s.accept_nudge(g));self.now+=600;self.assertTrue(self.s.accept_nudge(g))
    def test_next_check_no_spin(self):
        self.s.start();self.now+=120;self.s.begin();self.assertFalse(self.s.due())
    def test_fast_interval_rejected(self):
        with self.assertRaises(ValueError):ScreenSchedule(interval=1)
