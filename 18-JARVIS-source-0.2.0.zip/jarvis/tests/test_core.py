import base64
import io
import json
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core import Client, LocalError, prepare_image

class Handler(BaseHTTPRequestHandler):
    mode = 'ok'
    seen = None
    def log_message(self,*args):
        pass
    def do_GET(self):
        self.send_response(200); self.end_headers()
        self.wfile.write(json.dumps({'data':[{'id':'test-vision'}]}).encode())
    def do_POST(self):
        type(self).seen = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        if self.mode == 'redirect':
            self.send_response(302); self.send_header('Location','https://example.com'); self.end_headers(); return
        if self.mode == 'error':
            self.send_response(500); self.end_headers(); return
        self.send_response(200); self.end_headers()
        self.wfile.write(json.dumps({'choices':[{'message':{'content':'One step at a time, bro.'}}]}).encode())

class TestClient(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = HTTPServer(('127.0.0.1',0),Handler)
        threading.Thread(target=cls.server.serve_forever,daemon=True).start()
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close()
    def setUp(self):
        Handler.mode = 'ok'
        self.client = Client({'base_url':'http://127.0.0.1:%s/v1' % self.server.server_port})
    def test_models_and_chat(self):
        self.assertEqual(self.client.models(),['test-vision'])
        answer,seconds = self.client.ask('Help with Maya')
        self.assertIn('bro',answer); self.assertGreaterEqual(seconds,0)
        self.assertEqual(Handler.seen['model'],'test-vision')
        self.assertFalse(Handler.seen['stream'])
    def test_image_payload_not_retained(self):
        self.client.ask('What is shown?',b'test-image')
        payload=Handler.seen['messages'][-1]['content'][1]['image_url']['url']
        self.assertTrue(payload.startswith('data:image/jpeg;base64,'))
        self.assertNotIn('image_url',json.dumps(self.client.history))
    def test_bounded_memory_and_clear(self):
        for i in range(5): self.client.ask(str(i))
        self.assertEqual(len(self.client.history),6)
        self.client.clear(); self.assertEqual(self.client.history,[])
    def test_local_only(self):
        for url in ['https://example.com/v1','http://localhost:1234/v1','http://127.0.0.1:1234/v1?x=1','http://u:p@127.0.0.1:1234/v1']:
            with self.assertRaises(LocalError): Client({'base_url':url})
    def test_redirect_blocked(self):
        Handler.mode='redirect'
        with self.assertRaises(LocalError): self.client.ask('Hi')
    def test_server_error(self):
        Handler.mode='error'
        with self.assertRaises(LocalError): self.client.ask('Hi')
        self.assertEqual(self.client.history,[])
    def test_monitor_does_not_remember(self):
        self.client.ask("Observe this screen",b"image",remember=False)
        self.assertEqual(self.client.history,[])
    def test_invalid_input(self):
        for value in ['', 'x'*6001]:
            with self.assertRaises(LocalError): self.client.ask(value)
    def test_ambiguous_models(self):
        with patch.object(self.client,'models',return_value=['a','b']):
            with self.assertRaises(LocalError): self.client.resolve_model()
    def test_busy_guard(self):
        self.client.lock.acquire()
        with self.assertRaises(LocalError): self.client.ask('Hi')
        self.client.lock.release()
    def test_resize(self):
        from PIL import Image
        raw=io.BytesIO(); Image.new('RGB',(2560,1440)).save(raw,format='PNG')
        out=prepare_image(raw.getvalue())
        self.assertEqual(Image.open(io.BytesIO(out)).size,(1280,720))

if __name__ == '__main__': unittest.main()
