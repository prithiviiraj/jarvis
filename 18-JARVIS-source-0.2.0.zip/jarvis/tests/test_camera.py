import queue
import unittest
from unittest.mock import Mock, patch
from monitor import CameraMonitor
class TestCamera(unittest.TestCase):
    def test_failure_releases_device(self):
        events=queue.Queue(); camera=CameraMonitor(events)
        cap=Mock();cap.isOpened.return_value=False
        detector=Mock();detector.empty.return_value=False
        with patch('cv2.VideoCapture',return_value=cap),patch('cv2.CascadeClassifier',return_value=detector):camera.run(1)
        cap.release.assert_called_once()
        self.assertEqual(events.get_nowait()[0],'camera_error')
        self.assertEqual(events.get_nowait()[0],'camera_stopped')
    def test_stop_invalidates_events(self):
        camera=CameraMonitor(queue.Queue());old=camera.serial;camera.stop()
        self.assertGreater(camera.serial,old);self.assertTrue(camera.stop_event.is_set())
