"""Load user's existing bridge v4, adding commands without another poller."""
import importlib.util
from pathlib import Path
from bridge_adapter import Adapter

def main():
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    path = filedialog.askopenfilename(title='Select your existing bridge v4 bridge.py', filetypes=[('Bridge Python file','*.py')])
    root.destroy()
    if not path:
        print('Cancelled. No bridge started.')
        return
    if Path(path).name != 'bridge.py':
        raise RuntimeError('Choose the original bridge.py, not a new script.')
    spec = importlib.util.spec_from_file_location('existing_bridge',path)
    bridge = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bridge)
    for symbol in ('_ORIGINAL_GETADDRINFO','Bridge','is_owner','approve','capture_screen','MAX_AGE','main'):
        if not hasattr(bridge,symbol):
            raise RuntimeError('Not the expected bridge v4. No polling started.')
    adapter = Adapter(bridge)
    original = bridge.Bridge.handle
    def patched(instance,msg):
        if not adapter.handle(instance,msg):
            return original(instance,msg)
    bridge.Bridge.handle = patched
    bridge.HELP += '\nJARVIS: /ai <question>, /see <screen question>, /aiclear. Local approval required.'
    print('JARVIS adapter loaded. Stop the old bridge FIRST; only one listener may run.')
    bridge.main()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nStopped.')
    except Exception:
        print('Startup stopped. Check you selected the existing bridge v4 and stopped the old listener. No automatic retry.')
